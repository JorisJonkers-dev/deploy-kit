# What the render surface says the model still owes

Rendered by hand from the three worked projects, against the seven registered
adapters. Every row is something a renderer must produce and cannot produce from
intent as declared today. Read `knowledge/rendered/README.md` and
`data/RENDER-GAPS.md` for the per-file detail; this is the ordered list. The
`auth` tree has since been replaced by the renderer's own output, bound byte
for byte, and its per-file notes left with the hand-written files.

Fifty rendered files across `auth/`, `knowledge/` and `data/`. All parse.

Rows marked **closed** have since been decided; the row stays so the evidence
that forced the decision stays with it.

**Both blocking sections are discharged as of 2026-09-07.** R1–R11 are decided:
nine closed outright, R1 and R11 reclassified as obligations that were never the
render's, and R7's blocker (a grant that can name
`database/creds/<role>`) closed with R19 and R21 on the same day. What is left in this document is the fifteen model holes
below, each of which the compiler will force in turn, and the list of what the
decisions owe the example set.

## Blocking: no producer exists

| # | gap | seen in |
|---|---|---|
| R1 | **Atomic switchover is not expressible in plain Kubernetes objects.** Two Deployments in one Application each enter their own Endpoints when their own readiness passes. auth-ui (30s) serves a new bundle for up to the 600s auth-api is allowed to start, a new UI against an old API, both healthy. Nothing links them: the shared label is consumed by no controller, kustomize groups without gating, Flux health checks run after apply. **No rendered object has the identity "the Application".** **Reclassified** by [0052](../../../docs/adr/model/0052-an-application-is-the-release-unit.md): layer 2 derives the gate's inputs (member list, readiness references, each member's analysis checks, and a deadline of max member progressDeadlineSeconds), and a first-party Release Gate reads them and holds every member at a barrier until all have passed ([chapter 55](../55-delivery.md#the-release-gate)). No longer blocks the render. | auth |
| R2 | **The Vault policy and Kubernetes auth role have no producer.** `vso` emits VaultConnection / VaultAuth / VaultStaticSecret / VaultDynamicSecret, none is a policy or a role. Reached from `delivery: self` in auth and from `delivery: env` in data, so it is not a delivery-mode edge case. **Closed** by [0040](../../../docs/adr/model/0040-vault-policy-is-a-deliverable.md): a vault-policy adapter emits one JSON policy and one Kubernetes auth role per Process identity; writing them into Vault is delivery, and the auth mount is a platform fixture. | auth, data |
| R3 | **No `rbac` adapter and no `networking` adapter.** Every NetworkPolicy in these trees is what a future `networking` adapter must emit, and the only implementation lives in the generation being deleted. Three Applications share `data-system`; the only thing stopping valkey's ServiceAccount reading postgres' Secret is that no Role grants it, an absence, not a boundary. **Closed** by [0035](../../../docs/adr/model/0035-network-policy-is-default-deny-and-render-only.md) (a networking adapter owns every NetworkPolicy) and [0041](../../../docs/adr/model/0041-no-process-rbac-in-v1.md) (no process RBAC is rendered; the absence becomes E_PROCESS_RBAC_GRANT, a composition-time refusal). | data |
| R4 | **The forward-auth `Middleware` has no producer.** `traefik-public` emits IngressRoutes *with middleware references*, references only. Every `audience: authenticated` route in the estate resolves against a Middleware nothing renders. **Closed** by [0023](../../../docs/adr/model/0023-exposure-is-declared-by-audience.md): a traefik-middleware adapter owns every Middleware, and a tier serving `authenticated` names the endpoint that authenticates for it. | auth, data |
| R5 | **Durability renders nothing.** `irreplaceable` should derive a backup job, a retention sweep and an off-cluster copy; `recoverable` a job and a sweep; `reconstructible` nothing. No adapter reads the field, and schedule, retention window and destination have no declaring site in layer 1. PVC-level snapshots are impossible here (no VolumeSnapshot CRDs, no CSI snapshot support on `local-path`), so an application-level job is the *only* mechanism. **Closed** by [0018](../../../docs/adr/model/0018-durability-class-derives-a-backup.md): the Platform document carries one policy per class (window, retention, destination), the method is keyed by the Process's new `engine` field ([0019](../../../docs/adr/model/0019-engine-is-process-vocabulary.md)), and the kubernetes adapter emits the CronJob, whose method image keeps `retain` copies and prunes the rest, so no sweep is rendered. The destination credential is a derived grant, held by a backup identity of its own. | data, knowledge |
| R6 | **`alertClass` derives nothing.** Three Applications declare three different values and all three produce zero objects. No adapter renders a PrometheusRule in either generation. `platform-postgres` declares `page` and has no monitoring object at all, because Gatus derives from `exposure` and a datastore is correctly not exposed. **Closed** by [0025](../../../docs/adr/model/0025-observability-is-one-optional-block.md): the field is gone, and the declared `scrape` surface derives the ServiceMonitor. `platform-postgres` scrapes its exporter sidecar's surface rather than its exposure; `platform-valkey`, which has neither, declares no `observability` block at all. | data |
| R7 | **`init-databases.sh` is a derived catalog with no producer.** One database and one owning user per consumer, which the inbound edge set already knows. Chapter 16 calls it an inbound derivation; chapter 10 refuses it as an Asset because an Asset may not be executable. So it is a Deliverable, and nothing produces it. **Decided** by [0026](../../../docs/adr/model/0026-migration-is-declared-on-the-application.md): the render emits a declarative catalog (one entry per consumer: database, owning user, Vault role) and the platform's engine catalog applies it; credentials are issued by Vault's database engine, not stored. Blocked on R20 for a grant that can name `database/creds/<role>`. | data |

## Blocking: the object cannot be applied as rendered

| # | gap | seen in |
|---|---|---|
| R8 | **PVC capacity cannot be derived.** Capacity is platform-assigned and the author may not write it, yet no pinned input assigns a number. The node contract publishes `disks[].usable_gib` and no rule allocates from it. Rendered `storage: null`: parses, does not apply. **Closed** by [0017](../../../docs/adr/model/0017-placement-is-hard-dimensions.md): a volume authors `size` as a hard dimension, matched against the node contract's `usable_gib` (`E_STORAGE_UNSATISFIABLE`), and `placement.disk.size` becomes derived so the quantity has one declaring site. | data |
| R9 | **`runAsNonRoot: true` with no UID and no `fsGroup`, against RWO volumes.** A freshly provisioned `local-path` directory is root-owned; without `fsGroup`, postgres cannot `initdb` into its own PV. The images lock carries digests, not UIDs. If the image's `USER` is a name rather than a number the kubelet cannot verify non-root and the pod fails `CreateContainerConfigError`. **Closed** by [0020](../../../docs/adr/model/0020-hardening-is-one-platform-posture.md): the lock resolves `uid` and `gid` per alias, `runAsUser`/`runAsGroup`/`fsGroup` derive from them, a named `USER` is `E_IMAGE_USER_NOT_NUMERIC` at lock time, and `fsGroupChangePolicy: OnRootMismatch` keeps a large volume from being re-chowned on every start. | data |
| R10 | **auth-ui cannot bind port 80** under `runAsNonRoot` + `drop ALL` with only a `writableRootFilesystem` exception. Either the port is wrong or the exception set is. **Closed** by [chapter 14](../14-platform-intent.md#substrate-facts): the gap was not real. A pod off the host network binds any port without a capability on this substrate, so auth-ui provides 80 under the one posture, with every capability dropped. | auth |
| R11 | **Default-deny cannot ship non-enforcing.** `networking.k8s.io/v1` has no audit mode and k3s's embedded kube-router has none; a policy is enforced the moment it selects a pod. The audit stage the model sequences needs a CNI nobody has picked. Enforcing `data-system`'s policies on day one cuts five live consumers off the datastore. **Reclassified** by [0035](../../../docs/adr/model/0035-network-policy-is-default-deny-and-render-only.md): render-only is v1's stage, so the adapter emits the full set and nothing loads it until 0035 picks a CNI. The render is not waiting on the CNI; the promotion is. | data |

## Model holes the render exposed

| # | gap | seen in |
|---|---|---|
| R12 | **Which Application directory owns a per-project object.** `namespace.yaml` and the namespace-wide default-deny are one object per project; the adapter emits one directory per Application. auth has one Application so nothing collides; data has three, three identical Namespace objects at three paths, `E_PATH_COLLISION` waiting for a second writer. **Closed** by [0036](../../../docs/adr/model/0036-path-authority-is-layer-2.md): a per-project object is written once, in its Project's directory, so it has one owner, and a path claimed twice is refused on the assembled Deliverable set. | data, auth |
| R13 | **`automountServiceAccountToken` is underivable, and the obvious rule is wrong.** "No grant → no token" gets postgres backwards: it holds a grant and needs no token, because under `delivery: env` the operator performs the read and the pod never authenticates. The derivation must read `delivery`; no chapter states it. **Closed** by [0031](../../../docs/adr/model/0031-identity-per-process.md): the token is mounted only where a grant carries `delivery: self`, because that is the one case the pod authenticates; agents-api, which calls the Kubernetes API, restates it with a reason. | auth, data |
| R14 | **Probe derivation is partial.** `startupBudget` gives period × threshold and a progress deadline, but which endpoint the startup probe uses is unstated (chosen during serialisation, which chapter 30 forbids), and readiness/liveness `periodSeconds`, `failureThreshold` and `initialDelaySeconds` have no derivation. **Closed** by [0016](../../../docs/adr/model/0016-probes-are-siblings-and-startup-targets-liveness.md): the startup probe targets the liveness declaration, because exceeding its threshold kills the container; cadence comes from a Platform document probe policy and `initialDelaySeconds` is 0. | auth |
| R15 | **No writable-path vocabulary.** A read-only root filesystem needs `/tmp` for the JVM; that is prose in the intent, not a field. No `sizeLimit` is derivable, and a second writable path can only be had by relaxing the whole control. **Closed** by [0020](../../../docs/adr/model/0020-hardening-is-one-platform-posture.md): `writablePaths` is authored and each derives an `emptyDir`, its size comes from the Platform document's ephemeral `size`, the hardening control stays intact, and auth-ui's exception retires. | auth |
| R16 | **`replicas` and `minAvailable` are derived separately and never compared.** auth-api's eligible node set is one node, so live's two replicas is not reproducible; PDB `minAvailable: 1` against `replicas: 1` permits zero voluntary evictions, so draining that node (also the control plane) blocks forever. **Closed** by [0022](../../../docs/adr/model/0022-a-derived-value-has-one-declaring-site.md): `minAvailable` is deleted, `replicas` derives as 1 with more than one a `replicas: {count, reason}` declaration (the sole local capacity exception since the generic override hatch was deleted), and a PDB is emitted only above one replica as `maxUnavailable: 1`. | auth |
| R17 | **No exposure name and no hostname label.** Two anonymous exposures with no `paths` render two IngressRoutes with an identical match; Traefik breaks the tie by rule length then name. The live `/api` versus `/` split is expressible and is not declared. **Closed**: chapter 10 now requires `name` per exposure and `path` plus `match` per route, [0039](../../../docs/adr/model/0039-the-label-set-is-fixed.md) settled the label set with no hostname label, and [0023](../../../docs/adr/model/0023-exposure-is-declared-by-audience.md) derives precedence explicitly (`exact` before `prefix`, longer prefix first), with `E_DUPLICATE_ROUTE_MATCH` refusing an identical pair. | auth |
| R18 | **A cross-project edge outside the fragment set narrows the allow set silently.** `{application: stalwart, surface: smtp}` does not resolve, so the coordinates and the egress rule are absent rather than wrong, a valid policy with a missing rule, seen on-call as a timeout, not an error code. **Closed** by [0024](../../../docs/adr/model/0024-dependency-edges-resolve-against-the-union.md): an edge resolves against the union or the 0024 register, the register carries an address and ports per surface, and an entry without them is `E_PROVIDER_WITHOUT_COORDINATES`. | auth |
| R19 | **`self-roll` derives a capability that cannot perform the roll.** `patch` on a transit key permits neither `transit/keys/<name>/rotate` nor `transit/sign/<name>`. The access × path derivation needs a non-KV branch. **Closed** by [0029](../../../docs/adr/model/0029-a-grant-is-a-union-on-engine.md): a `transit` grant declares a key and a closed `operations` set (sign, verify, encrypt, decrypt, rotate), each mapping to one Vault path; the access tiers are KV intents only. | auth |
| R20 | **A grant path is not the path the credential is read from.** The dynamic database credential is granted at a KV-v2 path while the engine lives at `database/creds/<role>`, which no grant declares and no policy covers. **Closed** by [0029](../../../docs/adr/model/0029-a-grant-is-a-union-on-engine.md): every grant derives a read path, a `database` grant's is `database/creds/<role>`, and 0030's join key becomes that derived path, identical to the declared one for `kv`. | auth |
| R21 | **Byte-matched grant paths cannot reach their KV-v2 `metadata` sibling.** No transform is permitted, so version listing and soft-delete are denied to every reader in the estate. **Closed** by [0029](../../../docs/adr/model/0029-a-grant-is-a-union-on-engine.md): one `kv` declaration derives both `secret/data/<path>` and `secret/metadata/<path>`, since KV-v2 splitting one document across two API paths is an engine detail. Soft-delete stays out: it is a write. | auth |
| R22 | **`runtime: jvm` is asked to imply Spring Boot.** Four spring-cloud-vault spellings derive from `delivery: self`, and no field distinguishes a Spring JVM from any other. **Closed** by [0013](../../../docs/adr/model/0013-configuration-is-dotenv-at-three-scopes.md): nothing derives framework wiring (it stays in the Process's env file), and the one derived value it references comes through a closed `${identity:…}` placeholder source. | auth |
| R23 | **An Asset's change-propagation mechanism is unstated.** `onChange: restart` needs either a content-hashed ConfigMap name or a checksum annotation; no chapter picks one. `onChange` has two values and postgres supports `pg_ctl reload`, so under `Recreate` a one-line config edit is a full outage. **Closed** by [0014](../../../docs/adr/model/0014-file-shaped-configuration-is-an-asset.md): the object name is content-hashed unconditionally, `reload` is deleted along with the `onChange` field, and the outage is stated in the chapter as what an Asset edit costs on this substrate. | data |
| R24 | **The label set is not fixed anywhere.** `name` + `instance` are the Deployment selector and therefore immutable, changing the convention later is delete-and-recreate on every process in the estate. **Closed** by [0039](../../../docs/adr/model/0039-the-label-set-is-fixed.md): the five labels are named, part-of carries the Application, and name plus instance are named as immutable selectors. | auth |
| R25 | **No scrape `interval` or `scrapeTimeout` is derivable**, so omitting them silently takes the metrics stack's global default, decided outside the model. **Closed** by [0025](../../../docs/adr/model/0025-observability-is-one-optional-block.md): the Platform document states one `monitors: {interval, timeout}` for the estate and every emitted monitor names it, so the metrics stack's global default stops being an input nobody declared. | auth |
| R26 | **Estate-scoped Deliverables land in another project's namespace.** The Gatus endpoints ConfigMap is one object in `utility-system`, allowed only because the adapter owns the path rather than the Application. **Closed** by [0036](../../../docs/adr/model/0036-path-authority-is-layer-2.md): an estate-scoped Deliverable is written under `estate/`, which is no Project's, and the Gatus endpoints became each Application's own external checks ([0117](../../../docs/adr/model/0117-an-external-check-is-rendered-by-its-own-project.md)). | auth |

## The knowledge platform

[`knowledge-platform/`](knowledge-platform/knowledge-platform.project.yml) is
fleet-infra's knowledge platform (`cluster/flux/apps/knowledge-platform/` in
JorisJonkers-dev/fleet-infra), declared as intent and rendered by the compiler
into [`knowledge-platform/rendered/`](knowledge-platform/rendered/), bound byte
for byte in both implementations. Every row is something the live manifests do
that the declaration cannot say yet. None of them is guessed at in the project
file.

| # | gap | seen in |
|---|---|---|
| K1 | **A URL composed of two coordinates is not an env value.** A value holds one placeholder, with text only after it, so `http://${dependency:hindsight.host}:${dependency:hindsight.port}` is refused. Hindsight reads its embedding endpoint, its database and the console's API each as one URL, so `HINDSIGHT_API_EMBEDDINGS_TEI_URL`, `HINDSIGHT_API_DATABASE_URL` and `HINDSIGHT_CP_DATAPLANE_API_URL` are left out; the edges stay, and the egress they derive is right. Tracked as JorisJonkers-dev/deploy-kit#269. | hindsight |
| K2 | **Hindsight's database credential is not delivered.** Live, hindsight reads `hindsight_db` as its own user, with a static password held in its own Secret. The declaration grants no credential for it: the edge to `platform-postgres` derives the address and the egress, and the URL that would carry a credential is K1's. | hindsight |
| K3 | **No egress to the internet.** Every Application here calls out: OpenRouter for hindsight and karakeep, GitHub over SSH for git-sync, any page for the bookmark browser, the model hub for the embedding cache. The rendered NetworkPolicies admit only the declared edges, so each call is denied once the policies are loaded ([0035](../../../docs/adr/model/0035-network-policy-is-default-deny-and-render-only.md) keeps them render-only today). Tracked as JorisJonkers-dev/deploy-kit#270. | all five |
| K4 | **A sidecar runs no probe, and one image is told no mode.** Since JorisJonkers-dev/deploy-kit#271 a sidecar mounts the Process volumes it names, so git-sync works in `/vault` and meilisearch writes `/meili_data`, and git-clone runs as an init step before the server starts. Both sidecars still run unprobed, and git-clone and git-sync run one image, which the model hands no argument to tell cloning once from syncing. | basic-memory, karakeep |
| K5 | **Images that write their own root filesystem.** docling-serve, karakeep and chrome write under their home directories, which the restricted posture mounts read-only; no `writablePaths` are declared, because the paths are the images' internals rather than anything fleet-infra states. | docling-serve, karakeep |
| K6 | **Images that run as root.** karakeep, meilisearch and chrome run as the image's own user, root, live; the lock pins `uid` and `gid` 1000 for each, which the images have not been proven to run as. | karakeep |
| K7 | **Node pinning by hostname is not rendered.** fleet-infra pins each workload to one node; the declaration names only the site, and placement renders no affinity yet (JorisJonkers-dev/deploy-kit#259). | all five |
| K8 | **Left out: what is not one Process.** The ingest worker is parked at zero replicas and its copy Job is one-off; a Process has no zero and a one-off migration is no Process. LightRAG still runs in `knowledge-system`, so it stays with the `knowledge` example. Tracked as JorisJonkers-dev/deploy-kit#272. | knowledge-platform |
| K9 | **A grant reaches every container of the pod.** A sidecar gets the Process's variables and file grants, so the vault deploy key is mounted into the MCP server as well as git-sync, and karakeep's three secrets reach meilisearch and the page-loading chrome sidecar. Live, each container gets only what it uses; no field scopes a grant to one container. Tracked as JorisJonkers-dev/deploy-kit#274. | basic-memory, karakeep |

## The agents project

[`agents/`](agents/agents.project.yml) is what runs live in fleet-infra's
`agents-system` (`cluster/flux/apps/agents/` and `apps/stateless/agents-*` in
JorisJonkers-dev/fleet-infra, at `64f25b0e`): hermes and kubernetes-mcp-server,
with agents-api and agents-ui parked. It is declared as intent and rendered
into [`agents/rendered/`](agents/rendered/). Every row is something the live
manifests do that the declaration cannot say yet, and none of it is guessed at
in the project file.

| # | gap | seen in |
|---|---|---|
| A1 | **A Process takes no arguments.** hermes runs `gateway run`; kubernetes-mcp-server runs `--port=8080 --read-only`, without which it serves stdio and offers its write tools, refused then by its ClusterRole's verbs alone. Tracked as JorisJonkers-dev/deploy-kit#691. **Closed** by [0122](../../../docs/adr/model/0122-a-process-may-name-its-command-and-arguments.md): a Process names its `args`, and its `command` where the entrypoint is not it, as literal words. | hermes, kubernetes-mcp-server |
| A2 | **An image that starts as root.** hermes starts as root with a writable root filesystem and five capabilities to fix its data directory's ownership, then drops to uid 10000, and its skills step runs as root; the posture runs it as 10000 from the start, which it has not been shown to run as (as K5 and K6). Tracked as JorisJonkers-dev/deploy-kit#692. **Closed** by test, with no model change: hermes's pinned image runs under the posture as uid 10000, with `/run` and `/tmp` writable and s6-overlay told to accept a world-writable `/run`; the gateway runs and the dashboard answers (JorisJonkers-dev/deploy-kit#692, 2026-10-29). | hermes |
| A3 | **A config seeded onto the volume.** Two init steps copy `config.yaml` into hermes's data volume with the grant's values substituted, and install its skills, from three ConfigMaps, one of them executable scripts. An Asset is mounted read-only and may not be executable, so the steps and their files are left out; their contents are fleet-infra's. The grant's keys are read through the env file meanwhile. Tracked as JorisJonkers-dev/deploy-kit#693. **Closed** for the config by [0124](../../../docs/adr/model/0124-a-seeded-asset-is-copied-onto-a-volume-before-each-start.md): `config.yaml` is a seeded Asset, copied onto the volume before every start with the copy it replaces kept, and its secrets reach hermes through the env file, which hermes expands in the file itself. The skills sync is A8. | hermes |
| A4 | **A host the DNS provider must not proxy.** hermes's public host is grey-cloud, resolving straight to the Frankfurt edge, because Cloudflare closes the dashboard's idle WebSocket; the render gave it the tier's `proxied: true`. Tracked as JorisJonkers-dev/deploy-kit#694. **Closed** by [0127](../../../docs/adr/model/0127-an-exposure-may-bypass-the-dns-providers-proxy.md): hermes's public exposure declares `proxied: false`, so its record points at the public tier's `dns.direct`, the Frankfurt node's address, unproxied, and a rate limit on its routes would count a client by its connection. | hermes |
| A5 | **A memory-backed `/dev/shm`.** hermes mounts 1Gi of memory at `/dev/shm` for the browser its tools drive; a writable path is disk at the platform's one ephemeral size, so it is not declared. Tracked as JorisJonkers-dev/deploy-kit#695. **Closed** by [0123](../../../docs/adr/model/0123-a-writable-path-may-be-held-in-memory.md): a writable path held in memory sizes itself and counts toward the Process's memory. | hermes |
| A6 | **Optional keys.** Each of hermes's seven keys is optional live, where a missing one disables one tool; the render reads every key as required, so one missing key keeps hermes from starting. Tracked as JorisJonkers-dev/deploy-kit#696. **Closed** by [0126](../../../docs/adr/model/0126-a-grant-key-may-be-optional.md): a key may be written `{name, optional: true}`, and every reference the render makes to it is optional; hermes's seven keys are. | hermes |
| A7 | **One host split by path between two Applications.** `agents.jorisjonkers.dev` serves agents-ui but for `/api/`, which is agents-api's; a host on a tier is one exposure's (`E_DUPLICATE_HOST`), so agents-api's routes are left out while both are parked. Tracked as JorisJonkers-dev/deploy-kit#697. | agents-api, agents-ui |
| A8 | **A skills sync that fetches.** An init step clones each skill source `sources.conf` lists onto hermes's data volume before it starts, from a script in a ConfigMap. No Asset describes fetched content, and an Asset may not be executable, so the step is left out; hermes runs with the skills its image bundles. Tracked as JorisJonkers-dev/deploy-kit#706. | hermes |

## Missing inputs, not missing derivations

**Discharged on 2026-09-08**: every input this section lists is a block of the
worked Platform document ([`platform/platform.intent.yml`](platform/platform.intent.yml)),
in the model's words rather than Traefik's: a tier declares a `listener` and
`certificates`, and the adapter spells them as `entryPoints` and `certResolver`.
The paragraph below is kept as the record of what was missing.

Every platform-component fact the render needs is a Platform document input the
example set does not carry: cluster DNS, edge, metrics-stack and Secret Store
selectors; `release: metrics-stack` on the ServiceMonitor; entryPoints and
certResolver; `VAULT_ADDR`; `DEPLOYMENT_ENVIRONMENT`; the remaining `OTEL_*` and
`PYROSCOPE_*` Runtime Profile values. One coupling worth recording: if
`VAULT_ADDR` is the public hostname, the derived "egress to the Secret Store"
rule selects pods the traffic never reaches.

Also missing from the example set itself: auth-ui has no env file, so its
container renders with no env at all: the model requires one per Process and
the set carries one of two.

## What the closed rows owed the example set

**Discharged on 2026-09-07.** Layer 1 was updated, the Platform document was
written, and the rendered trees were stripped of commentary and re-rendered
against the decisions. What each row owed is listed below for the record; the
per-tree summary of what changed is in each `rendered/README.md`.

Two items are deliberately still owed, because they are not the example set's
to answer: the node contract is a separate pinned input and is not reproduced
here ([0048](../../../docs/adr/model/0048-node-facts-are-authored-once.md)), and
`auth-ui` still has no env file of its own: the model requires one per Process
and the set carries one of two.

### The list, as it stood

Every **Closed** row above decided something the worked examples predate, so the
three project files and the Platform document inputs are behind the model. This is
the list, and it is discharged in one pass rather than row by row: the trees are
also being stripped of commentary, and both edits touch the same files.

| owed | from | where |
|---|---|---|
| `engine` on every datastore Process | [0019](../../../docs/adr/model/0019-engine-is-process-vocabulary.md) | `data`, `knowledge` |
| `minAvailable` removed, and `auth-api`'s second replica declared as `replicas: {count, reason}` with its capacity reason | [0022](../../../docs/adr/model/0022-a-derived-value-has-one-declaring-site.md) | `auth`, and any rendered PDB over a single replica |
| the probe policy, and every rendered probe naming its cadence | [0016](../../../docs/adr/model/0016-probes-are-siblings-and-startup-targets-liveness.md) | Platform document, all three rendered trees |
| `automountServiceAccountToken` on every pod template | [0031](../../../docs/adr/model/0031-identity-per-process.md) | all three rendered trees |
| `writablePaths` on every non-static Process, and auth-ui's `writableRootFilesystem` exception deleted | [0020](../../../docs/adr/model/0020-hardening-is-one-platform-posture.md) | `auth`, `knowledge` |
| the `${identity:…}` placeholder in auth-api's env file, replacing the literal role name | [0013](../../../docs/adr/model/0013-configuration-is-dotenv-at-three-scopes.md) | `auth` env files |
| `onChange` removed from every Asset | [0014](../../../docs/adr/model/0014-file-shaped-configuration-is-an-asset.md) | `data` |
| `size` on every volume | [0017](../../../docs/adr/model/0017-placement-is-hard-dimensions.md) | `data`, `knowledge` |
| `placement.disk.size` removed: it is now derived | [0017](../../../docs/adr/model/0017-placement-is-hard-dimensions.md) | `data` declares `size: 100Gi` under `disk` |
| a scrape surface for `platform-postgres` | [0025](../../../docs/adr/model/0025-observability-is-one-optional-block.md) | `data`: `platform-postgres` scrapes its exporter sidecar |
| the durability policy per class, and the backup method per `engine` | [0018](../../../docs/adr/model/0018-durability-class-derives-a-backup.md) | Platform document |
| the alert rule catalog and the class-to-receiver mapping | [0025](../../../docs/adr/model/0025-observability-is-one-optional-block.md) | deleted, not relocated: alert rules are the monitoring stack's own files. Monitor cadence is one line in the Platform document (2026-09-10) |
| coordinates for every provider an edge targets, starting with `stalwart`'s SMTP | [0024](../../../docs/adr/model/0024-dependency-edges-resolve-against-the-union.md) | Platform document |
| a forward-auth endpoint on every tier serving `authenticated` | [0023](../../../docs/adr/model/0023-exposure-is-declared-by-audience.md) | Platform document |
| explicit precedence on every rendered IngressRoute | [0023](../../../docs/adr/model/0023-exposure-is-declared-by-audience.md) | `auth`, `knowledge`, `data` edge trees |
| the label set as fixed, on every rendered object | [0039](../../../docs/adr/model/0039-the-label-set-is-fixed.md) | all three rendered trees |
| the release gate's inputs in each projection | [0052](../../../docs/adr/model/0052-an-application-is-the-release-unit.md) | `resolved.yml` examples |
