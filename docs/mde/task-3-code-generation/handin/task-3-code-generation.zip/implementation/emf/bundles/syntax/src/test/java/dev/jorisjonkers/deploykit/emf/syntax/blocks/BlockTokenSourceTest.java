package dev.jorisjonkers.deploykit.emf.syntax.blocks;

import static org.assertj.core.api.Assertions.assertThat;

import dev.jorisjonkers.deploykit.emf.syntax.parser.antlr.ProjectIntentTokenSource;
import dev.jorisjonkers.deploykit.emf.syntax.parser.antlr.internal.InternalProjectIntentParser;
import dev.jorisjonkers.deploykit.emf.syntax.parser.antlr.lexer.InternalProjectIntentLexer;
import java.util.ArrayList;
import java.util.List;
import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CommonToken;
import org.antlr.runtime.Token;
import org.junit.jupiter.api.Test;

/** The block structure the grammar reads, as the tokens this source produces for authored YAML. */
class BlockTokenSourceTest {

    /** Every token of {@code text}, hidden ones included. */
    private static List<Token> tokens(String text) {
        ProjectIntentTokenSource source =
                new ProjectIntentTokenSource(new InternalProjectIntentLexer(new ANTLRStringStream(text)));
        List<Token> tokens = new ArrayList<>();
        for (Token token = source.nextToken(); token.getType() != Token.EOF; token = source.nextToken()) {
            tokens.add(token);
        }
        return tokens;
    }

    /** Every significant token of {@code text}, as "BEGIN", "END" or its own text. */
    private static List<String> blocks(String text) {
        ProjectIntentTokenSource source =
                new ProjectIntentTokenSource(new InternalProjectIntentLexer(new ANTLRStringStream(text)));
        List<String> tokens = new ArrayList<>();
        for (Token token = source.nextToken(); token.getType() != Token.EOF; token = source.nextToken()) {
            if (token.getType() == InternalProjectIntentParser.RULE_BEGIN) {
                tokens.add("BEGIN");
            } else if (token.getType() == InternalProjectIntentParser.RULE_END) {
                tokens.add("END");
            } else if (token.getType() != InternalProjectIntentParser.RULE_WS
                    && token.getType() != InternalProjectIntentParser.RULE_SL_COMMENT) {
                tokens.add(BlockTokenSource.valueOf(token.getText()));
            }
        }
        return tokens;
    }

    @Test
    void theSourceNameIsTheOneTheLexerGives() {
        assertThat(new ProjectIntentTokenSource(new InternalProjectIntentLexer(new ANTLRStringStream("a: 1")))
                        .getSourceName())
                .isEqualTo(new InternalProjectIntentLexer(new ANTLRStringStream("a: 1")).getSourceName());
    }

    @Test
    void anIndentedLineOpensABlockAndFallingBackClosesIt() {
        assertThat(blocks("a:\n  b:\n    c: 1\nd: 2\n"))
                .containsExactly("a", ":", "BEGIN", "b", ":", "BEGIN", "c", ":", "1", "END", "END", "d", ":", "2");
    }

    @Test
    void everyBlockStillOpenAtTheEndOfTheFileIsClosed() {
        assertThat(blocks("a:\n  b:\n    c: 1")).endsWith("1", "END", "END");
    }

    @Test
    void aDashOpensABlockAroundTheItemThatFollowsIt() {
        assertThat(blocks("a:\n  - b: 1\n    c: 2\n  - b: 3\n"))
                .containsExactly(
                        "a", ":", "BEGIN", "-", "BEGIN", "b", ":", "1", "c", ":", "2", "END", "-", "BEGIN", "b", ":",
                        "3", "END", "END");
    }

    @Test
    void aFlowMappingIsABlockOnOneLine() {
        assertThat(blocks("a: { b: 1, c: 2 }\n"))
                .containsExactly("a", ":", "BEGIN", "b", ":", "1", "c", ":", "2", "END");
    }

    @Test
    void aDashFollowedByAFlowMappingOpensOneBlock() {
        assertThat(blocks("a:\n  - { b: 1 }\n  - { b: 2 }\n"))
                .containsExactly(
                        "a", ":", "BEGIN", "-", "BEGIN", "b", ":", "1", "END", "-", "BEGIN", "b", ":", "2", "END",
                        "END");
    }

    @Test
    void aBlockOpenedByAFlowMappingIsClosedWithIt() {
        assertThat(blocks("a: { b: 1 }\nc:\n  d: 2\n"))
                .containsExactly("a", ":", "BEGIN", "b", ":", "1", "END", "c", ":", "BEGIN", "d", ":", "2", "END");
    }

    @Test
    void aSyntheticTokenSitsWhereTheTokenThatAskedForItSits() {
        ProjectIntentTokenSource source =
                new ProjectIntentTokenSource(new InternalProjectIntentLexer(new ANTLRStringStream("a:\n  b: 1\n")));
        List<Token> tokens = new ArrayList<>();
        for (Token token = source.nextToken(); token.getType() != Token.EOF; token = source.nextToken()) {
            tokens.add(token);
        }
        Token begin = tokens.stream()
                .filter(token -> token.getType() == InternalProjectIntentParser.RULE_BEGIN)
                .findFirst()
                .orElseThrow();
        CommonToken key = (CommonToken) tokens.stream()
                .filter(token -> "b".equals(token.getText()))
                .findFirst()
                .orElseThrow();

        assertThat(begin.getText()).isEmpty();
        assertThat(begin.getLine()).isEqualTo(key.getLine());
        assertThat(begin.getCharPositionInLine()).isEqualTo(key.getCharPositionInLine());
        assertThat(((CommonToken) begin).getStartIndex()).isEqualTo(key.getStartIndex());
        assertThat(((CommonToken) begin).getStopIndex()).isEqualTo(key.getStartIndex() - 1);
    }

    @Test
    void indentationInsideAFlowMappingIsNotRead() {
        assertThat(blocks("a: { b: 1,\n        c: 2 }\nd: 3\n"))
                .containsExactly("a", ":", "BEGIN", "b", ":", "1", "c", ":", "2", "END", "d", ":", "3");
    }

    @Test
    void aCommentLineOpensNoBlock() {
        assertThat(blocks("a: 1\n      # a comment, indented\nb: 2\n")).containsExactly("a", ":", "1", "b", ":", "2");
    }

    @Test
    void aFoldedScalarIsOneValueWithItsLinesJoinedBySpaces() {
        assertThat(blocks("a: >-\n  one line\n  and another\nb: 2\n"))
                .containsExactly("a", ":", "one line and another", "b", ":", "2");
    }

    @Test
    void aLiteralScalarKeepsItsLineBreaks() {
        assertThat(blocks("a: |-\n  one line\n  and another\n")).containsExactly("a", ":", "one line\nand another");
    }

    @Test
    void aFoldWithoutAChompKeepsTheClosingLineBreak() {
        assertThat(blocks("a: >\n  one line\n")).containsExactly("a", ":", "one line\n");
    }

    @Test
    void aBlankLineInsideAFoldedScalarIsNotRead() {
        assertThat(blocks("a: >-\n  one\n\n  two\n")).containsExactly("a", ":", "one two");
    }

    @Test
    void aBlankLineInsideALiteralScalarIsKept() {
        assertThat(blocks("a: |-\n  one\n\n  two\n")).containsExactly("a", ":", "one\n\ntwo");
    }

    @Test
    void whatFollowsAFoldedScalarIsReadAsUsual() {
        assertThat(blocks("a: >-\n  one\n  # not a comment, part of the scalar\nb:\n  c: 2\n"))
                .containsExactly(
                        "a", ":", "one # not a comment, part of the scalar", "b", ":", "BEGIN", "c", ":", "2", "END");
    }

    @Test
    void aFoldedScalarSitsWhereItsMarkerSatAndCoversItsWholeBlock() {
        String source = "a: >-\n  one line\n  and another\nb: 2\n";

        CommonToken folded = (CommonToken) tokens(source).stream()
                .filter(token -> token.getText().startsWith(">"))
                .findFirst()
                .orElseThrow();

        assertThat(folded.getLine()).isEqualTo(1);
        assertThat(folded.getCharPositionInLine()).isEqualTo(3);
        assertThat(folded.getStartIndex()).isEqualTo(source.indexOf('>'));
        assertThat(folded.getStopIndex()).isEqualTo(source.indexOf("another") + "another".length() - 1);
    }

    @Test
    void everyCharacterOfTheFileIsCoveredByExactlyOneToken() {
        String source = "a: >-\n  one\n  two\n\nb:\n  c: 2\nd: { e: 1, f: [x, y] }\n";
        int next = 0;

        for (Token token : tokens(source)) {
            CommonToken common = (CommonToken) token;
            if (!token.getText().isEmpty()) {
                assertThat(common.getStartIndex()).as(token.getText()).isEqualTo(next);
                next = common.getStopIndex() + 1;
            }
        }

        assertThat(next).isEqualTo(source.length());
    }

    @Test
    void aFoldedScalarsTokenCoversItsSourceSoWhatFollowsSitsWhereItsTextIs() {
        String source = "a: >-\n  one line\n  and another\nb: 2\n";

        assertThat(tokens(source).stream().map(Token::getText).filter(text -> text.startsWith(">")))
                .containsExactly(">-\n  one line\n  and another");
        assertThat(BlockTokenSource.valueOf("")).isEmpty();
        assertThat(BlockTokenSource.valueOf("|\n  kept")).isEqualTo("kept\n");
    }

    @Test
    void aValueOfSeveralWordsIsOnePlainScalarToTheEndOfItsLine() {
        assertThat(blocks("a: one two, three # a comment\nb: 2\n"))
                .containsExactly("a", ":", "one two, three", "b", ":", "2");
        assertThat(blocks("a: { b: one two, c: [x, y] }\n"))
                .containsExactly("a", ":", "BEGIN", "b", ":", "one two", "c", ":", "BEGIN", "x", "y", "END", "END");
        assertThat(blocks("a: { b: one two }\n")).containsExactly("a", ":", "BEGIN", "b", ":", "one two", "END");
        assertThat(blocks("a: one\nb:\n  - c\n"))
                .containsExactly("a", ":", "one", "b", ":", "BEGIN", "-", "BEGIN", "c", "END", "END");
    }

    @Test
    void aFlowSequenceIsAnEmptyBlockRatherThanAnItem() {
        assertThat(blocks("a: []\n")).containsExactly("a", ":", "BEGIN", "END");
    }

    @Test
    void aValueThatClosesAFlowOrOpensAnItemIsNoPlainScalar() {
        assertThat(blocks("a: { b: }\n")).containsExactly("a", ":", "BEGIN", "b", ":", "END");
        assertThat(blocks("a: - b c\n")).containsExactly("a", ":", "-", "BEGIN", "b", "c", "END");
    }

    @Test
    void aPlainScalarOfSeveralWordsSitsWhereItsFirstWordSatAndCoversItsSourceOnce() {
        String source = "a: one two  three # c\n";
        CommonToken scalar = (CommonToken) tokens(source).stream()
                .filter(token -> token.getText().equals("one two  three"))
                .findFirst()
                .orElseThrow();

        assertThat(scalar.getLine()).isEqualTo(1);
        assertThat(scalar.getCharPositionInLine()).isEqualTo(3);
        assertThat(scalar.getStartIndex()).isEqualTo(3);
        assertThat(scalar.getStopIndex()).isEqualTo(16);
        int next = 0;
        for (Token token : tokens(source)) {
            CommonToken common = (CommonToken) token;
            if (!token.getText().isEmpty()) {
                assertThat(common.getStartIndex()).as(token.getText()).isEqualTo(next);
                next = common.getStopIndex() + 1;
            }
        }
        assertThat(next).isEqualTo(source.length());
    }

    @Test
    void aMarkerWithNothingUnderItIsOneLineBreak() {
        assertThat(BlockTokenSource.valueOf("|")).isEqualTo("\n");
    }
}
