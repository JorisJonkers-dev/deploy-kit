package dev.jorisjonkers.deploykit.emf.cli;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.ProjectIntentPackage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** The constraints a parsed document answers, and the diagnostics a violation becomes. */
class ConstraintsTest {

    private static final String REFUSED = """
            apiVersion: intent.jorisjonkers.dev/v1
            kind: Project
            schemaVersion: 1.0.0
            project: refusals
            owner: joris
            applications:
              - id: unwired
                processes:
                  - name: unwired-worker
                    lifecycle: scheduled
                    image: unwired-worker
                    runtime: node
                    placement:
                      memory: 128Mi
                      cpu: 25m
            """;

    private static Path file(Path directory, String text) throws IOException {
        Path file = directory.resolve("unwired.project.yml");
        Files.writeString(file, text);
        return file;
    }

    @Test
    void aViolationCarriesTheInvariantsNameAndThePointerOfWhatItRefused(@TempDir Path directory) throws IOException {
        Parsed parsed = Pipeline.intent(file(directory, REFUSED));

        assertThat(parsed.ok()).isFalse();
        assertThat(parsed.intent()).isEmpty();
        assertThat(parsed.diagnostics()).singleElement().satisfies(diagnostic -> {
            assertThat(diagnostic.code()).isEqualTo("E_SCHEDULE_MISSING");
            assertThat(diagnostic.document()).isEqualTo("unwired.project.yml");
            assertThat(diagnostic.path()).isEqualTo("/applications/0/processes/0");
            assertThat(diagnostic.message()).contains("E_SCHEDULE_MISSING");
        });
    }

    private static final String ACCEPTED = """
            apiVersion: intent.jorisjonkers.dev/v1
            kind: Project
            schemaVersion: 1.0.0
            project: refusals
            owner: joris
            applications:
              - id: wired
                observability:
                  scrape:
                    process: wired-worker
                    surface: http
                    path: /metrics
                processes:
                  - name: wired-worker
                    lifecycle: application
                    image: wired-worker
                    runtime: node
                    provides:
                      http: 8080
                    placement:
                      memory: 128Mi
                      cpu: 25m
                    cutover: continuous
            """;

    @Test
    void aDocumentThatBreaksNoConstraintCarriesNoDiagnostic(@TempDir Path directory) throws IOException {
        Parsed parsed = Pipeline.intent(file(directory, ACCEPTED));

        assertThat(parsed.diagnostics()).isEmpty();
        assertThat(parsed.intent()).containsKey("applications");
    }

    @Test
    void theConstraintsAreTheFileTheMetamodelCarries() {
        assertThat(Constraints.beside(ProjectIntentPackage.class, "project-intent.ocl")
                        .toString())
                .endsWith("project-intent.ocl");
    }

    @Test
    void aPostgresOnAVolumeThatDerivesNoBackupDeclaresItsEngine() {
        // Its consumers' database catalog derives from the engine, so the engine is not decoration
        // (docs/adr/model/0019-engine-is-process-vocabulary.md).
        assertThat(Pipeline.intent(Examples.of("refusals/engine-owns-databases.project.yml"))
                        .diagnostics())
                .isEmpty();
        assertThat(Pipeline.intent(Examples.of("refusals/engine-without-durability.project.yml"))
                        .diagnostics())
                .extracting(Diagnostic::code)
                .containsExactly("E_ENGINE_WITHOUT_DURABILITY");
    }

    @Test
    void aClaimIsTheProjectsAloneBackupClaimIncluded() {
        // A project's Processes share one namespace, and a claim is named as written
        // (spec/v1/10-project-intent.md#storage-and-durability).
        assertThat(Pipeline.intent(Examples.of("refusals/duplicate-claim.project.yml"))
                        .diagnostics())
                .extracting(Diagnostic::code, Diagnostic::path)
                .containsExactly(tuple("E_DUPLICATE_CLAIM", "/applications/0/processes/1/volumes/0"));
        assertThat(Pipeline.intent(Examples.of("refusals/duplicate-backup-claim.project.yml"))
                        .diagnostics())
                .extracting(Diagnostic::code, Diagnostic::path)
                .containsExactly(tuple("E_DUPLICATE_CLAIM", "/applications/0/processes/1/volumes/0"));
    }

    @Test
    void aGeneratedKeyAdoptsOnlyAValueItsProjectAlreadyReads() {
        assertThat(Pipeline.intent(Examples.of("refusals/generated-key-adopts-granted.project.yml"))
                        .diagnostics())
                .isEmpty();
        assertThat(Pipeline.intent(Examples.of("refusals/generated-key-adopts-ungranted.project.yml"))
                        .diagnostics())
                .extracting(Diagnostic::code)
                .containsExactly("E_GENERATED_KEY_ADOPTS_UNGRANTED");
    }
}
