package dev.jorisjonkers.deploykit.emf.metamodel.descriptor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EEnumLiteral;
import org.eclipse.emf.ecore.EModelElement;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;

/**
 * The structure of a metamodel, in the shape the parity contract fixes: every class with its
 * features, each feature's types and multiplicity, and every closed vocabulary with its literals
 * (docs/architecture.md#the-parity-contract).
 *
 * <p>The shape is neither Ecore's nor the wire schema's. An abstract class is the union of what can
 * stand in its place, so it is not listed and a feature that points at one names its concrete
 * classes. A map entry is not a class either: the feature that holds the entries is a map. A class
 * the language writes as the value of one of its features is that feature's type, so a plain key
 * is a {@code string}. And a class nobody authors is not listed: the lowered Project and Application are what a transformation
 * writes (docs/adr/model/0125).
 */
public final class Descriptor {

    private static final String JSON = "https://jorisjonkers.dev/deploy-kit/json";
    private static final Map<String, String> PRIMITIVES =
            Map.of("java.lang.String", "string", "java.lang.Integer", "int", "java.lang.Boolean", "boolean");

    private Descriptor() {}

    /** The descriptor of {@code metamodel}, as a JSON value. */
    public static Map<String, Object> of(EPackage metamodel) {
        List<Object> classes = new ArrayList<>();
        List<Object> vocabularies = new ArrayList<>();
        for (EClassifier classifier : sorted(metamodel.getEClassifiers())) {
            switch (classifier) {
                case EEnum vocabulary -> vocabularies.add(vocabulary(vocabulary));
                case EClass owner -> {
                    if (isListed(owner)) {
                        classes.add(owner(owner));
                    }
                }
                default ->
                    throw new IllegalArgumentException(
                            classifier.getName() + " is neither a class nor a closed vocabulary");
            }
        }
        return Map.of("classes", classes, "vocabularies", vocabularies);
    }

    private static List<EClassifier> sorted(List<EClassifier> classifiers) {
        return classifiers.stream()
                .sorted(Comparator.comparing(EClassifier::getName))
                .toList();
    }

    /** Whether a class is one the descriptor lists: an abstract class is a union, a map entry a map. */
    private static boolean isListed(EClass owner) {
        return !owner.isAbstract()
                && !isMapEntry(owner)
                && !"no".equals(detail(owner, "authored"))
                && detail(owner, "value") == null;
    }

    /** The descriptor spells a class as its document spells it, and `env` is a directory beside one. */
    private static boolean isInTheDocument(EStructuralFeature feature) {
        return !"no".equals(detail(feature, "document"));
    }

    /** The key a document writes a feature under: its name, unless the name is no Java identifier. */
    public static String keyOf(EStructuralFeature feature) {
        String key = detail(feature, "key");
        return key == null ? feature.getName() : key;
    }

    /** What this element's JSON annotation says under {@code key}, or nothing where it carries none. */
    private static String detail(EModelElement element, String key) {
        EAnnotation json = element.getEAnnotation(JSON);
        return json == null ? null : json.getDetails().get(key);
    }

    private static boolean isMapEntry(EClassifier classifier) {
        return Map.Entry.class.getName().equals(classifier.getInstanceClassName());
    }

    private static Map<String, Object> vocabulary(EEnum vocabulary) {
        Map<String, Object> json = new LinkedHashMap<>();
        json.put("name", vocabulary.getName());
        // A literal with no spelling is the model's way of saying "unset", which is
        // not a value the language can write and not part of the vocabulary.
        json.put(
                "literals",
                vocabulary.getELiterals().stream()
                        .map(EEnumLiteral::getLiteral)
                        .filter(literal -> !literal.isEmpty())
                        .toList());
        return json;
    }

    private static Map<String, Object> owner(EClass owner) {
        Map<String, Object> json = new LinkedHashMap<>();
        json.put("name", owner.getName());
        json.put(
                "features",
                owner.getEAllStructuralFeatures().stream()
                        .filter(Descriptor::isInTheDocument)
                        .sorted(Comparator.comparing(Descriptor::keyOf))
                        .map(Descriptor::feature)
                        .toList());
        String scalar = detail(owner, "scalar");
        if (scalar != null) {
            json.put("scalar", scalar);
        }
        return json;
    }

    private static Map<String, Object> feature(EStructuralFeature feature) {
        boolean map = feature instanceof EReference containment
                && containment.isContainment()
                && isMapEntry(containment.getEReferenceType());
        boolean linked = feature instanceof EReference reference && !reference.isContainment();
        Map<String, Object> json = new LinkedHashMap<>();
        json.put("name", keyOf(feature));
        json.put("types", linked ? List.of(feature.getEType().getName()) : types(feature, map));
        json.put("required", feature.isRequired());
        json.put("many", feature.isMany() && !map);
        json.put("map", map);
        json.put("reference", linked);
        if (map) {
            String entry = detail(feature.getEType(), "entry");
            json.put("entry", entry == null ? feature.getEType().getName() : entry);
        }
        return json;
    }

    /** The types a feature admits: a vocabulary, a primitive, a class, or the classes a union stands for. */
    private static List<String> types(EStructuralFeature feature, boolean map) {
        if (map) {
            EClass entry = ((EReference) feature).getEReferenceType();
            return types(entry.getEStructuralFeature("value"), false);
        }
        EClassifier type = feature.getEType();
        if (feature instanceof EAttribute) {
            return List.of(type instanceof EEnum ? type.getName() : PRIMITIVES.get(type.getInstanceClassName()));
        }
        EClass referenced = (EClass) type;
        if (!referenced.isAbstract()) {
            return List.of(nameOf(referenced));
        }
        return referenced.getEPackage().getEClassifiers().stream()
                .filter(EClass.class::isInstance)
                .map(EClass.class::cast)
                .filter(candidate -> !candidate.isAbstract() && referenced.isSuperTypeOf(candidate))
                .map(Descriptor::nameOf)
                .sorted()
                .toList();
    }

    /** A class by its name, or by the type of the one feature the language writes it as. */
    private static String nameOf(EClass candidate) {
        String value = detail(candidate, "value");
        return value == null
                ? candidate.getName()
                : types(candidate.getEStructuralFeature(value), false).getFirst();
    }
}
