package dev.jorisjonkers.deploykit.emf.resolve;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.groups.Tuple.tuple;

import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Application;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Credentials;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Cutover;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.DependencyEdge;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.EffectiveApplication;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.EffectiveProject;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.EnvFile;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.EnvLiteral;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.EnvVariable;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.KvGrant;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Lifecycle;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.ManagedMigration;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Placement;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.PlainKey;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.PlainPath;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Process;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Project;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.ProjectIntentFactory;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.ProjectIntentPackage;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Rotation;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Tolerance;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.WritablePathDeclaration;
import java.util.List;
import org.junit.jupiter.api.Test;

/**
 * REQ-036: Shared Intent declared at the Project or an Application reaches every Process below it,
 * lists extend each other, and the lowest declaration of one thing holds
 * (spec/v1/10-project-intent.md#the-effective-intent).
 */
class LoweringTest {

    private static final ProjectIntentFactory MODEL = ProjectIntentFactory.eINSTANCE;

    /** One declaration of each shape the merge has to get right. */
    private static Project source() {
        Project project = MODEL.createProject();
        project.setApiVersion("intent.jorisjonkers.dev/v1");
        project.setKind("Project");
        project.setSchemaVersion("1.0.0");
        project.setProject("refusals");
        project.setOwner("joris");
        project.getSecrets().add(grant("secret/data/refusals/estate-ca"));
        project.getWritablePaths().add(path("/tmp"));
        project.setPlacement(dimensions("enschede"));

        Application application = MODEL.createApplication();
        application.setId("shared-intent-merged");
        application.getSecrets().add(grant("secret/data/refusals/queue"));
        application.setCutover(Cutover.INTERRUPTED);

        Process api = process("shared-intent-merged-api", "128Mi", "25m");
        api.getSecrets().add(grant("secret/data/refusals/bearer"));
        api.getWritablePaths().add(path("/var/cache/api"));

        Process worker = process("shared-intent-merged-worker", "64Mi", "10m");
        worker.getPlacement().setSite("frankfurt");

        application.getProcesses().add(api);
        application.getProcesses().add(worker);
        project.getApplications().add(application);
        return project;
    }

    private static KvGrant grant(String path) {
        KvGrant grant = MODEL.createKvGrant();
        grant.setPath(path);
        PlainKey key = MODEL.createPlainKey();
        key.setName("token");
        grant.getKeys().add(key);
        return grant;
    }

    private static PlainPath path(String written) {
        PlainPath path = MODEL.createPlainPath();
        path.setPath(written);
        return path;
    }

    private static Placement dimensions(String site) {
        Placement placement = MODEL.createPlacement();
        placement.setSite(site);
        return placement;
    }

    private static Process process(String name, String memory, String cpu) {
        Process process = MODEL.createProcess();
        process.setName(name);
        process.setLifecycle(Lifecycle.APPLICATION);
        process.setImage(name);
        Placement placement = MODEL.createPlacement();
        placement.setMemory(memory);
        placement.setCpu(cpu);
        process.setPlacement(placement);
        return process;
    }

    private static EffectiveProject lower(Project project) {
        return Lowering.lower(project);
    }

    private static Process lowered(EffectiveProject project, String name) {
        EffectiveApplication application = project.getApplications().get(0);
        return application.getProcesses().stream()
                .filter(process -> name.equals(process.getName()))
                .findFirst()
                .orElseThrow();
    }

    private static List<String> paths(Process process) {
        return process.getSecrets().stream()
                .map(KvGrant.class::cast)
                .map(KvGrant::getPath)
                .sorted()
                .toList();
    }

    @Test
    void everyProcessHoldsTheGrantsOfEveryLevelAboveItExtendedByItsOwn() {
        EffectiveProject lowered = lower(source());

        assertThat(paths(lowered(lowered, "shared-intent-merged-api")))
                .containsExactly(
                        "secret/data/refusals/bearer", "secret/data/refusals/estate-ca", "secret/data/refusals/queue");
        // A sibling holds fewer, so the lists extend rather than have to match.
        assertThat(paths(lowered(lowered, "shared-intent-merged-worker")))
                .containsExactly("secret/data/refusals/estate-ca", "secret/data/refusals/queue");
    }

    @Test
    void eachNodeDimensionComesFromTheLowestLevelThatSetItAndTheQuantitiesFromTheProcess() {
        EffectiveProject lowered = lower(source());

        Placement api = lowered(lowered, "shared-intent-merged-api").getPlacement();
        assertThat(api.getMemory()).isEqualTo("128Mi");
        assertThat(api.getSite()).isEqualTo("enschede");
        // The Process replaces `site`: each key merges on its own.
        Placement worker = lowered(lowered, "shared-intent-merged-worker").getPlacement();
        assertThat(worker.getMemory()).isEqualTo("64Mi");
        assertThat(worker.getSite()).isEqualTo("frankfurt");
    }

    @Test
    void theMigrationStaysOnTheApplicationAndAnEdgeKeepsItsCredentials() {
        Project project = source();
        Application application = project.getApplications().get(0);
        ManagedMigration migration = MODEL.createManagedMigration();
        migration.setChangelog("db/changelog.yml");
        application.setMigration(migration);
        DependencyEdge edge = MODEL.createDependencyEdge();
        edge.setApplication("platform-postgres");
        edge.setSurface("postgres");
        Credentials credentials = MODEL.createCredentials();
        Rotation rotation = MODEL.createRotation();
        rotation.setTolerates(Tolerance.RESTART);
        credentials.setRotation(rotation);
        edge.setCredentials(credentials);
        application.getProcesses().get(0).getDependsOn().add(edge);

        EffectiveApplication lowered = lower(project).getApplications().get(0);

        assertThat(((ManagedMigration) lowered.getMigration()).getChangelog()).isEqualTo("db/changelog.yml");
        assertThat(lowered.getProcesses().get(0).getDependsOn())
                .singleElement()
                .satisfies(
                        copy -> assertThat(copy.getCredentials().getRotation().getTolerates())
                                .isEqualTo(Tolerance.RESTART));
    }

    @Test
    void theCutoverQuestionIsAnsweredOnceForTheReleaseUnitThatSwitchesTogether() {
        EffectiveProject lowered = lower(source());

        assertThat(lowered.getApplications().get(0).getProcesses())
                .allSatisfy(process -> assertThat(process.getCutover()).isEqualTo(Cutover.INTERRUPTED));
    }

    @Test
    void aPrepareProcessTakesNoSharedCutoverBecauseItCutsOverNothing() {
        Project project = source();
        Process seed = process("seed", "64Mi", "10m");
        seed.setLifecycle(Lifecycle.PREPARE);
        project.getApplications().get(0).getProcesses().add(seed);

        EffectiveProject lowered = lower(project);

        assertThat(lowered.getApplications().get(0).getProcesses())
                .extracting(Process::getName, Process::getCutover)
                .containsExactly(
                        tuple("shared-intent-merged-api", Cutover.INTERRUPTED),
                        tuple("shared-intent-merged-worker", Cutover.INTERRUPTED),
                        tuple("seed", Cutover.ABSENT));
    }

    @Test
    void theWritablePathsExtendAndTheLoweredLevelsHoldOnlyWhatDefinesThem() {
        EffectiveProject lowered = lower(source());

        assertThat(lowered(lowered, "shared-intent-merged-api").getWritablePaths())
                .extracting(WritablePathDeclaration::getPath)
                .containsExactly("/var/cache/api", "/tmp");
        assertThat(lowered(lowered, "shared-intent-merged-worker").getWritablePaths())
                .extracting(WritablePathDeclaration::getPath)
                .containsExactly("/tmp");
        // No SharedIntent at all, which is what makes the wrong level unreadable.
        assertThat(ProjectIntentPackage.eINSTANCE.getEffectiveApplication().getEAllStructuralFeatures())
                .extracting(feature -> feature.getName())
                .containsExactlyInAnyOrder(
                        "id",
                        "description",
                        "client",
                        "l4Exposure",
                        "dashboards",
                        "alertRules",
                        "migration",
                        "observability",
                        "exposure",
                        "processes");
    }

    @Test
    void leavesTheDocumentHeaderBehind() {
        assertThat(ProjectIntentPackage.eINSTANCE.getEffectiveProject().getEAllStructuralFeatures())
                .extracting(feature -> feature.getName())
                .containsExactly("project", "owner", "applications");
        assertThat(lower(source()).getProject()).isEqualTo("refusals");
    }

    @Test
    void anEnvVariableKeepsItsValueOnTheProcessItReaches() {
        Project project = source();
        EnvFile file = MODEL.createEnvFile();
        EnvVariable variable = MODEL.createEnvVariable();
        variable.setName("NODE_ENV");
        EnvLiteral literal = MODEL.createEnvLiteral();
        literal.setText("production");
        variable.setValue(literal);
        file.getEntries().add(variable);
        project.getEnv().add(file);

        Process api = lowered(lower(project), "shared-intent-merged-api");

        assertThat(api.getEnv()).singleElement().satisfies(lowered -> {
            assertThat(lowered.getEntries()).singleElement().satisfies(entry -> {
                assertThat(entry.getName()).isEqualTo("NODE_ENV");
                assertThat(((EnvLiteral) entry.getValue()).getText()).isEqualTo("production");
            });
        });
    }
}
