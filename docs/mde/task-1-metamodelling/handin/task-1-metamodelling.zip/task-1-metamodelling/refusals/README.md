# Refused models

Every model here is one the pipeline rejects. Each is the authored YAML file and,
beside it, its XMI. The table says which XMI holds the error, the code it
reports (Appendix B of the report says what each code rejects), and how to see
it. Open an XMI with Open With > Sample Reflective Ecore Model Editor.

- **Validate**: select the root object and choose Validate. The constraints
  embedded in `model/project-intent.ecore` report the code.
- **Both files + OCL document**: a folder is a platform document and a project
  file that are only wrong together, so each file alone validates. The OCL
  document must see both files:
  1. Open the project file's XMI, `refusals.project.xmi`.
  2. Right-click in the editor, choose Load Resource..., and add
     `platform.intent.xmi` from the same folder.
  3. Choose OCL > Load Document and select `model/project-intent.ocl`. Load it
     after step 2, so it sees both files.
  4. Select the root object of `refusals.project.xmi` and choose Validate.
- **Unresolved reference**: the model names something no document declares.
  Validate reports that the reference is an unresolved proxy, which is the
  rejection; the code is the pipeline's name for it.

| Model | Code | How to see it |
|---|---|---|
| `alert-class-without-signal.project.xmi` | E_ALERT_CLASS_WITHOUT_SIGNAL | Validate |
| `credentials-without-database/refusals.project.xmi` | E_CREDENTIALS_WITHOUT_DATABASE | both files + OCL document |
| `cutover-continuous-over-rwo.project.xmi` | E_CUTOVER_UNHONOURABLE | Validate |
| `cutover-missing.project.xmi` | E_CUTOVER_MISSING | Validate |
| `cutover-mixed.project.xmi` | E_RELEASE_UNIT_MIXED_CUTOVER | Validate |
| `duplicate-route-match.project.xmi` | E_DUPLICATE_ROUTE_MATCH | Validate |
| `durability-without-engine.project.xmi` | E_DURABILITY_WITHOUT_ENGINE | Validate |
| `engine-without-durability.project.xmi` | E_ENGINE_WITHOUT_DURABILITY | Validate |
| `env-cannot-reload.project.xmi` | E_ENV_CANNOT_RELOAD | Validate |
| `handover-both-paths/platform.intent.xmi` | E_HANDOVER_BOTH_PATHS | Validate |
| `handover-unlisted/refusals.project.xmi` | E_HANDOVER_UNLISTED | both files + OCL document |
| `illegal-delivery-for-access.project.xmi` | E_ILLEGAL_DELIVERY_FOR_ACCESS | Validate |
| `migration-owner-duplicated.project.xmi` | E_MIGRATION_OWNER_DUPLICATED | Validate |
| `migration-undeclared/refusals.project.xmi` | E_MIGRATION_UNDECLARED | both files + OCL document |
| `migration-without-database/refusals.project.xmi` | E_MIGRATION_WITHOUT_DATABASE | both files + OCL document |
| `no-delivery-policy/refusals.project.xmi` | E_NO_DELIVERY_POLICY | both files + OCL document |
| `no-durability-policy/refusals.project.xmi` | E_NO_DURABILITY_POLICY | both files + OCL document |
| `no-engine-policy/refusals.project.xmi` | E_NO_ENGINE_POLICY | both files + OCL document |
| `no-forward-auth-endpoint/platform.intent.xmi` | E_NO_FORWARD_AUTH_ENDPOINT | Validate |
| `no-migration-policy/refusals.project.xmi` | E_NO_MIGRATION_POLICY | both files + OCL document |
| `no-tier-for-audience/refusals.project.xmi` | E_NO_TIER_FOR_AUDIENCE | both files + OCL document |
| `non-kv-delivery.project.xmi` | E_NON_KV_DELIVERY | Validate |
| `owner-role-granted.project.xmi` | E_OWNER_ROLE_GRANTED | Validate |
| `placement-incomplete.project.xmi` | E_PLACEMENT_INCOMPLETE | Validate |
| `prepare-process-serves.project.xmi` | E_PREPARE_PROCESS_SERVES | Validate |
| `scrape-unknown-process.project.xmi` | E_UNKNOWN_PROCESS | unresolved reference |
| `secrets-at-rest-required/refusals.project.xmi` | E_SECRETS_AT_REST_REQUIRED | both files + OCL document |
| `secrets-at-rest-required-at-header/refusals.project.xmi` | E_SECRETS_AT_REST_REQUIRED | both files + OCL document |
| `shared-declaration-duplicated.project.xmi` | E_SHARED_DECLARATION_DUPLICATED | Validate |
| `shared-quantity.project.xmi` | E_SHARED_QUANTITY | Validate |
| `unknown-machinery/platform.intent.xmi` | E_UNKNOWN_MACHINERY | unresolved reference |
| `unknown-surface.project.xmi` | E_UNKNOWN_SURFACE | unresolved reference |
| `unknown-tier-proxy/platform.intent.xmi` | E_UNKNOWN_TIER_PROXY | unresolved reference |
