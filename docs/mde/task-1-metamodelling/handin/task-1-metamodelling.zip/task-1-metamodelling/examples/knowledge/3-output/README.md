# Rendered output: the `knowledge` project

Hand-executed Deliverable Set for
[`knowledge.project.yml`](../knowledge.project.yml) and its env files. One
project, two Applications of one Process each, namespace `knowledge-system`.

**Split on 2026-09-24.** `knowledge-api` releases continuously and
`knowledge-ingest-worker` cannot (its ReadWriteOnce volume forces a stop-start
cutover), and one Application switches as one, so the worker is now Application
`knowledge-ingest` ([0128](../../../../../docs/adr/model/0128-cutover-names-the-promise.md)).
Its objects moved to `apps/knowledge-ingest/`; the namespace-wide `default-deny`
and the two secrets both Applications share moved to the project level
(`networkpolicy.yaml`, `vso.yaml`), as the `data` project already does. The
attribution table below predates the split and still names every object under
`apps/knowledge/`; the objects are the same, only their directory moved.

This is the **goal state**, not what the tree emits today. Every object carries
`securityContext` from the hardening class and `resources` from `placement`;
images are digests from the images lock; there is no HorizontalPodAutoscaler,
because autoscaling is not in the model; storage is `local-path`, because no
PVC in the estate sets a `storageClassName`.

Adapter attribution lives on the **Fragment** record (`{path, content, adapter}`),
not on the object, and the files carry no header comment stating it: rendered
output carries no commentary. The table below is the attribution, and nothing in
the rendered YAML carries it machine-readably, see G-30.

## Comment-free, and what this pass changed

The tree carries **no commentary**: one `GENERATED. Never hand-edit.` header line
per file, emitted by the serializer as a constant, and then the object.
Everything the files used to explain in comments belongs here or in a decision.

Re-rendered against the decisions of 2026-09-07, so this pass added the objects
that had no producer and made explicit three things a renderer had been choosing:

| change | decided in |
|---|---|
| the fixed label set, `instance` now the Process and `component` the runtime | [0072](../../../../../docs/adr/model/0072-the-label-set-is-fixed.md) |
| `automountServiceAccountToken`, `false` wherever the pod does not authenticate | [0087](../../../../../docs/adr/model/0087-token-mounted-only-for-delivery-self.md) |
| `runAsUser`, `runAsGroup`, and `fsGroup` on the Process holding the clone | [0082](../../../../../docs/adr/model/0082-images-lock-carries-uid-and-gid.md) |
| a startup probe pointed at the **liveness** endpoint, and one probe cadence | [0088](../../../../../docs/adr/model/0088-startup-probe-targets-liveness.md) |
| an `emptyDir` for the JVM's `/tmp`, at the platform's ephemeral size | [0092](../../../../../docs/adr/model/0092-writable-paths-are-declared.md) |
| explicit route `priority` on all five routes, rather than a rule-length sort | [0093](../../../../../docs/adr/model/0093-route-precedence-is-derived.md) |
| `size` on the PVC, and the backup a Durability Class derives | [0081](../../../../../docs/adr/model/0081-volume-size-is-a-hard-dimension.md), [0077](../../../../../docs/adr/model/0077-durability-derives-a-backup.md) |

**The "cannot derive today" column below is largely historical.** Those rows
were decided on 2026-09-07 and their status lives in
[`../../RENDER-GAPS.md`](../../RENDER-GAPS.md) rather than being restated here.

## Estate-scoped objects are not in this tree

Two files this tree used to carry, `edge/middlewares.yaml` and
`observability/gatus-endpoints.yaml`, render in the **platform projects** now:
the Middleware set is emitted per tier by the `traefik` adapter into the edge
project, and the Gatus endpoint list is an inbound derivation rendered as the
declared `gatus` Application's own Asset in the observability project
([0096](../../../../../docs/adr/model/0096-the-foundation-is-declared.md),
[0098](../../../../../docs/adr/model/0098-one-publication-path.md)). This project
contributes routes and exposures to both; it owns neither object.

## Emitted

| file | adapter | derives from | cannot derive today |
|---|---|---|---|
| `namespace.yaml` | `kubernetes` | `project` | none (the adapter emits this per *Application* directory, not per project: **G-02**) |
| `kustomization.yaml` | `kubernetes` | the Application set of the project | - |
| `apps/knowledge/workload.yaml` | `kubernetes` | `lifecycle`, `image`, `runtime`, `provides`, `placement`, `hardening`, `probes`, `startupBudget`, `cutover`, `stateful`, `volumes`, `secrets`, env files | `replicas` (`minAvailable` ungraded); the image's UID behind `runAsNonRoot`; a scratch volume for a read-only-root JVM (**G-04**); what `stateful` changes about the object kind (**G-05**); the PV-bound node (**G-06**); env-var renaming through `envFrom` (**G-03**); readable mode on the 0400 key (**G-08**) |
| `apps/knowledge/serviceaccount.yaml` | `kubernetes` | process `name` × 2, `project` | none (the adapter names one account after the *Application*: **G-09**) |
| `apps/knowledge/configmap.yaml` | `kubernetes` | env files, `dependsOn`, the `provides` port, Cluster Target, process `name` | 15 of the 16 Runtime Profile keys (**G-13**); the database name spelling (**G-12**); change propagation on edit (**G-10**) |
| `apps/knowledge/pvc.yaml` | `kubernetes` | `volumes[].claim`, `volumes[].durability`, `stateful` | `resources.requests.storage`: **the object does not apply without it** (**G-15**); the durability annotation key (**G-14**) |
| `apps/knowledge/servicemonitor.yaml` | `prometheus` (a `PodMonitor`) | `observability.scrape {process, surface, path}`, `provides` | cadence from the Platform document |
| `apps/knowledge/networkpolicy.yaml` | `networking`, **not registered** (**G-16**) | `dependsOn`, `provides`, `exposure`, `scrape`, effective grant set, baseline | egress to anything outside the estate, the worker's git remote (**G-20**); ingress from consumers absent from the union (**G-18**); whether a namespace catch-all is emitted (**G-17**) |
| `apps/knowledge/canary.yaml` | `kubernetes` | `cutover: continuous`, the Platform document's `delivery.analysis`, the Application revision | none; the Services and the primary are Flagger's ([chapter 30](../../../30-deliverables.md#flagger-ready-objects)) |
| `apps/knowledge/migration.yaml` | `kubernetes` | `migration.changelog`, the Platform document's `migration` policy, the Application revision and the migration's `testedAgainst` | the owner credential's Vault role, which no adapter writes yet. The file holds the migration identity, this revision's migration, and the suspended down that only the Release Gate runs ([chapter 55](../../../55-delivery.md#failure-and-undo)) |
| `apps/knowledge/vso.yaml` | `vso` | `secrets` at both levels, `delivery`, `rotation`, process `name` | Secret/object naming (**G-21**); which identity reads a shared path (**G-23**); the Kubernetes auth mount name |
| `apps/knowledge/kustomization.yaml` | `kubernetes` | the emitted file set | ownership of `vso.yaml` (**G-25**) |
| `edge/ingressroutes.yaml` | `traefik`, for the tier each route's audience selects | the Application's `exposure`: authored `host`, the exposure `audience` and five routes, four overriding it to `anonymous`, each naming `knowledge-api` and its `http` surface | - |
| `apps/knowledge/backup.yaml` | `kubernetes` | `durability: irreplaceable` plus `engine: files` on the vault clone | none (0077) |
| `apps/vso-secrets/policies/knowledge-api.policy.json` | `vault-policy` | the three KV grants, each with its `metadata` sibling | none (0073, 0086) |
| `apps/vso-secrets/policies/knowledge-api.role.json` | `vault-policy` | the Process's ServiceAccount and namespace | - |

## Deliberately absent, and correct

| not emitted | why it is right |
|---|---|
| a Kubernetes `Service` for `knowledge-ingest-worker` | it declares no `provides`. A RabbitMQ consumer opens no listener, so there is no surface, nothing may `dependsOn` it, and there is no address to route to. |
| a `ServiceMonitor` or `PodMonitor` for `knowledge-ingest-worker` | no `scrape` is declared, and a ServiceMonitor selects an Application it does not have. |
| any probe on `knowledge-ingest-worker` | `probes: none` is **declared**, so the absence is a decision rather than a forgotten block, and a readiness gate on a Process that can never report ready would stop the Application switching for ever. |
| `podmonitor.yaml`, `hpa.yaml` | nothing declares a pod-level scrape; autoscaling is not in this model. |
| `traefik` routes | no path rule carries the `lan` audience. |

## Demanded by the model, produced by nothing

| object | demanded by | producer today |
|---|---|---|
| backup `CronJob` + retention sweep + off-cluster copy | `durability: irreplaceable` on `knowledge-vault-clone` | **none.** No adapter reads `durability`, and even with one, three values have no declaring site: the schedule, the retention window and the off-cluster destination. Not rendered rather than invented (**G-31**). |
| `PodDisruptionBudget` | the `kubernetes` adapter builds one from an availability field | **not derivable.** `minAvailable` is ungraded and no `replicas` assignment exists; a PDB over a single-replica Deployment blocks every node drain (**G-32**). |
| `PrometheusRule` | nothing in this model | **correctly none.** PromQL, severity and receivers belong to the monitoring stack, which reads `alertClass` from the projection. |
| `Role` / `RoleBinding` per Process | per-Process identity | **none.** No `rbac` adapter. It is also what keeps the two Secret boundaries apart in a shared namespace (**G-24**). |
| `resolved.yml` (the `ResolvedApplication` projection) | publish-back | central composition; not part of a Deliverable Set. |

Estate-scoped objects this project contributes rows to but does not render: the
edge catalogs, now Assets of the declared Traefik Applications in the platform edge
project; the Gatus endpoint list, an Asset of the declared `gatus` Application; and
`vso`'s `VaultConnection` in `vso-system`. The per-Process image digests that
were once an `image-metadata` document are in this Application's `resolved.yml`
projection, and the Flux `Kustomization` for `apps-knowledge` is delivery's
([0098](../../../../../docs/adr/model/0098-one-publication-path.md)).

## Gaps

**G-01** The `kubernetes` adapter keys every object off the *Application* name and
emits one controller per Application directory. Two Processes in one Application
overwrite each other. Nothing about the adapter is per-Process.

**G-02** The same adapter emits `namespace.yaml` inside each Application directory.
A project with three Applications emits three identical `Namespace` objects at three
paths.

**G-03** `envFrom: secretRef` injects the Secret's **own key names**. The env
file asks for `DB_USER=${secret:…#user}` and `RABBITMQ_USER=${secret:…#rabbitmq.user}`,
so envFrom yields `user` and `rabbitmq.user`, and the second is not a legal
environment variable name at all. The rule "literal keys become plain env
entries, `${secret:…}` keys become envFrom secretRef entries" cannot deliver the
renaming the placeholder mechanism promises. It needs per-variable
`valueFrom.secretKeyRef`, or a VSO `destination.transformation` template. This
is the largest hole in the model as written.

**G-04** `readOnlyRootFilesystem: true` on a JVM needs a writable `/tmp`. Layer 1
has no vocabulary for an ephemeral volume, `volumes` carries `claim`, `mountAt`
and `durability` only, so neither the author nor the renderer can produce one.

**G-05** Object kind is documented as derived from `lifecycle` + `stateful` +
`volumes`, but chapter 20's own projection renders `Deployment` for
`knowledge-ingest-worker`, which is `stateful: true` with a volume. With
`volumeClaimTemplate` forbidden, what `stateful` changes about the kind is
unstated; here it only selects the 10m health timeout class.

**G-06** The example set contains no `ClusterState` snapshot, so `placement.boundTo`,
`from: clusterState` and the PV's node affinity cannot be rendered. Every
statement about reproducibility depends on a collector that does not exist.

**G-07** `startupBudget: 120s` on a Process with `probes: none` feeds only
`progressDeadlineSeconds`. Its other stated consumer, the startup probe's
period and threshold, has nothing to configure, so half the derivation is dead
for this shape.

**G-08** `fileMode: "0400"` on a projected Secret writes a file owned `root:root`.
The container runs as a non-root UID from the image under `hardening: restricted`.
As declared, the process cannot read its own deploy key. Repairing it needs
`fsGroup` or a known UID, neither of which layer 1 can express, and the two
declarations that collide are in the same Process block.

**G-09** `serviceAccountName()` returns the Application name today, so both pods
authenticate as one principal and receive the union of both policies. That gives
the internet-facing API `read` on the ingest worker's SSH deploy key. The
declaration and the identity must ship together.

**G-10** `onChange: restart` content-hashes an **Asset's** object name. No rule
states what an **env file's** ConfigMap does, so an edit to `base.env` applies
successfully and never reaches the running pod, the failure 16 of the estate's
18 ConfigMaps already have.

**G-11** A `${dependency:…}` coordinate resolves to the provider's Kubernetes
`Service`, which is named for the provider's **Process** (`postgres`), not for
the Application id the consumer wrote (`platform-postgres`). Chapter 16 promises a
provider may move a surface between its own Processes "without a single consumer
edit"; the resolved coordinate in the consumer's ConfigMap changes when it does.

**G-12** `${dependency:platform-postgres.database}` resolves to `knowledge_db`.
The `<application>_db` spelling is evidenced by `init-databases.sh` and specified in
no chapter. The set of legal coordinate names (`host`, `port`, `database`, …) is
not enumerated anywhere either.

**G-13** `runtime: jvm` injects 10 `OTEL_*` and 6 `PYROSCOPE_*` keys; `runtime:
python` injects 6. Exactly one of them, `OTEL_SERVICE_NAME`, is a function of
anything declared. The other fifteen are constants held in a **Runtime Profile**,
and chapter 20's pinned input set does not include one, and it lists Intent
Fragments, the Platform document and node contract, the images lock and the
ClusterState snapshot. A render cannot be a pure function of pinned inputs while
16 env vars come from an unpinned source.

**G-14** Durability is carried onto the PVC as an annotation so a delivery
mechanism can refuse to prune it, which is one of the model's three demands. No
chapter names the annotation key, so the demand has no wire format.

**G-15** PVC capacity is "assigned" and forbidden to the author, but no pinned
input carries an assignment: the node contract publishes `disks[].usable_gib`
and no rule allocates a number to a claim. For an existing claim the bound PV's
capacity would come from the ClusterState snapshot (see G-06). **A PVC without
`resources.requests.storage` does not apply**, so this blocks the file, not just
a field.

**G-16** No registered adapter emits `NetworkPolicy`. The only implementation
ever written is in the generation being deleted, so coverage for the kind goes
from unregistered to absent while default-deny becomes normative.

**G-17** Whether the derivation emits a namespace-scoped catch-all in addition to
per-Process policies is unstated. It matters more than it looks: the namespace
holds every Application of the project, so one project's catch-all governs Applications
added to the file later and never reviewed against it.

**G-18** `knowledge-api`'s ingress allow set contains no consumer rule, because
nothing in the composed example set declares an edge to `knowledge`. In the live
estate the agents Applications do. A provider's policy is therefore a function of
**which fragments are in the union**: a project that silently fails to publish
narrows its *providers'* ingress, and the pod that breaks is not in the project
that broke. Chapter 40's stale-participant check is a correctness gate here, not
hygiene.

**G-19** "Egress to the Secret Store, from the Processes holding the grant" is
derived from any grant. All four grants here are `delivery: env` or `file`, where
the VSO operator does the reading and the pod never opens a connection to Vault.
The rule should be conditioned on `delivery: self`; as stated it grants Vault
reachability to pods that never use it.

**G-20** `knowledge-ingest-worker` holds an SSH deploy key at 0400 and a claim
called `knowledge-vault-clone`, so it must reach a git host **outside the
cluster**. `dependsOn` can only name an Application Id in the composed union, so no
declaration can produce that egress rule. Under default-deny the Process cannot
do the job the grant exists for, and no field in layer 1 can say so.

**G-21** The derived `Secret` / `VaultStaticSecret` name is load-bearing, for it is
what `envFrom` and the projected volume reference, and no chapter states the
rule. This render uses the granted path minus the mount and `data/`, with `/`
replaced by `-`.

**G-22** The registered `vso` adapter emits one `VaultAuth`, in `vso-system`, on
the operator's own ServiceAccount and role. Under it the operator reads every
path for everyone and the two derived per-Process Vault roles do nothing for
`env` or `file` delivery. This render emits one `VaultAuth` per Process
instead; that is the goal state, and it is a different object graph.

**G-23** An Application-level grant has two eligible identities. The model states no
tie-break for which one performs the read, and the choice is visible in the
rendered object.

**G-24** With `delivery: env`/`file` the per-Process Vault boundary is
re-materialised as a namespace-scoped Kubernetes `Secret`. It holds only because
nothing grants `get secrets` in `knowledge-system`, and there is no `rbac`
adapter to render such a Role, nor to prove none exists.

**G-25** `vso.yaml` sits in the Application directory here but the registered adapter
writes to `apps/vso-secrets/<name>.yaml` with its own kustomization. Three
central adapters already declare the same `platform/cluster/flux/apps` prefix
and `E_PATH_COLLISION` has zero occurrences under `src/`.

**G-26 is retired.** The IngressRoutes need a hostname and the Application now
authors one: `host: knowledge.jorisjonkers.dev` on its `public` exposure, a full
FQDN with five named routes under it. Nothing assembles it from a label, a tier
policy and a cluster domain, the estate also answers on `kb.jorisjonkers.dev`,
and no rule could have picked between them. The id is not reused and the gaps
below are not renumbered.

**G-27** The `gatus` adapter's `defaultPath` places the ConfigMap under
`apps/utility-system/gatus/`, while the observability pack runs gatus in
namespace `observability` and mounts a ConfigMap named `gatus-endpoints`. A
ConfigMap in the wrong namespace is not mounted and is not an error.

**G-28** The only declared health path is matched by the `/` route, whose
audience is `authenticated`, so an external probe is answered by forward-auth.
The endpoint must be internal, which means nothing checks that
`knowledge.jorisjonkers.dev` resolves, that the certificate is valid, or that the
IngressRoutes match, and the six artefacts the exposure block unified are still
unverified end to end. What is missing is not the URL, which the authored host
and the route path now give, but a route whose audience is anonymous over a
health path.

**G-29** `alertClass: business-hours` renders no rule here, which is now the
model's position rather than a hole: the class is published as a resolved fact
and the monitoring stack owns what a class means. Its out-degree is not zero, and
the `observability` block it sits in also carries the `scrape` surface the
`ServiceMonitor` above derives from. The historic defect this records is that
the gatus ConfigMap carried `endpoints` only and no adapter emitted a receiver
or a notifier route, so nothing downstream acted on the class at all.

**G-30** Attribution is a property of the Fragment record, so the rendered YAML
carries no machine-readable adapter. A diff over the tree cannot name the
producer without joining to the Fragment set; the header comments here are
documentation.

**G-31** `durability` has no reader in either renderer generation. Even given an
adapter, `irreplaceable` needs a schedule, a retention window and an off-cluster
destination, and none of the three has a declaring site in any layer.

**G-32** `minAvailable` is ungraded and no `replicas` assignment appears in
chapter 20's projection, so `pdb.yaml` cannot be produced. Guessing `minAvailable: 1`
over a one-replica Deployment blocks every node drain permanently.

**G-33** The `restricted` class is defined as exactly four controls and does not
include `allowPrivilegeEscalation: false`, which the Pod Security Standards
profile of the same name requires. A pod rendered from this class does not
satisfy PSA `restricted`, so the class name promises more than it delivers.

**G-34** Probe timings are stated only for the startup probe (`periodSeconds: 5`,
threshold = budget ÷ 5) and `timeoutSeconds: 5`. `periodSeconds`,
`initialDelaySeconds` and `failureThreshold` for readiness and liveness are fixed
by no rule; this render omits them and takes Kubernetes' defaults.

**G-35** Chapter 20's worked projection for `knowledge-ingest-worker` shows
`memory: 512Mi`, `cpu: 100m` and `disk: {media: [nvme], size: 100Gi}`. The intent
file declares `256Mi`, `50m` and no `disk` dimension. This render follows the
intent and invents no dimension. The chapter's example needs correcting, or the
two disagree about what the same Process asks for.

**G-36** `E_SECRETS_AT_REST_REQUIRED` blocks all four grants until the pinned
Platform document advertises `secretsEncryption: true`, so **none of this project
ships** on today's inputs. There is no Platform document in the example
set to check against.

**G-37** ~~The restart targets name `knowledge-api`.~~ **Closed**: they name
`knowledge-api-primary`, the Deployment Flagger promotes into
([chapter 55](../../../55-delivery.md#secret-rotation)), now that `canary.yaml`
renders the Canary.
