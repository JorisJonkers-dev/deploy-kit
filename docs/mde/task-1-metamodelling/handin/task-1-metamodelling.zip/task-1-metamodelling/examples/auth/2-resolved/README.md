No resolved model is committed for `auth` yet: the transformation that produces it is Task 2. The minimal and knowledge examples carry one.
