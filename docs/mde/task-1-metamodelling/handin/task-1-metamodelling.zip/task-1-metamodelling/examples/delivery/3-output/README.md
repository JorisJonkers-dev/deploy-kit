No generated tree is committed for `delivery`: it exists to show a resolved model, not a render.
