No resolved model is committed for `data` yet: the transformation that produces it is Task 2. The minimal and knowledge examples carry one.
