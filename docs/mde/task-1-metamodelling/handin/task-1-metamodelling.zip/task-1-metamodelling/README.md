# Task 1 hand-in: metamodels and models

`report.pdf` is the report. Everything else is copied from the repository
(github.com/JorisJonkers-dev/deploy-kit), and nothing here is edited by hand.

| path | what it holds |
|---|---|
| `metamodels/` | the source metamodel `project-intent.ecore` with its constraints `project-intent.ocl`, and the target metamodel `resolved-deployment.ecore` |
| `examples/<name>/1-input/` | the authored project file in concrete syntax, its env files where it has them, `intent.xmi` (the same model as an instance of the source metamodel, written by the model-driven pipeline) and `intent.json` (its parsed form, the oracle both implementations are tested against) |
| `examples/<name>/2-resolved/` | the resolved model, the state in between: `minimal.resolveddeployment` is an XMI instance of the target metamodel; `resolved*.json` are the projections of the production implementation |
| `examples/<name>/3-output/` | the generated file tree |
| `examples/platform/` | the Platform document every example is read beside, and its model |
| `refusals/` | every refused model, each with the `*.diagnostics.json` it must produce; a directory is a set of documents read together |

Every XMI and JSON file has a YAML view beside it, named after it with `.yml`
appended (`intent.xmi.yml`, `resolved.json.yml`, `minimal.resolveddeployment.yml`).
The conversion is mechanical: an XMI element becomes a mapping, its attributes
fields, and its children a field named by the feature that holds them, a list
exactly where the metamodel's feature is many-valued; `xsi:type` becomes `type`,
a reference path becomes the name of the object it points at, and a map's
key/value entries become a mapping. Nothing is added or dropped. The XMI and JSON
files remain the models themselves; the views are for reading.

The examples, and what each one exercises, are in section 8 and Appendix A of
the report.
