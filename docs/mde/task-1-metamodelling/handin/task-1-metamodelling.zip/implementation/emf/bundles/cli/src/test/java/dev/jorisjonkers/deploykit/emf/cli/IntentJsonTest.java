package dev.jorisjonkers.deploykit.emf.cli;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.entry;

import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.AnalysisPolicy;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Application;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.DeliveryPolicy;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.HttpProbe;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Lifecycle;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Match;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Placement;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Probes;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Process;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.ProjectIntentFactory;
import dev.jorisjonkers.deploykit.emf.metamodel.projectintent.Route;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

/** What the intent of a parsed model holds: the authored keys, and nothing the document left out. */
class IntentJsonTest {

    private static final ProjectIntentFactory MODEL = ProjectIntentFactory.eINSTANCE;

    private static Process process() {
        Process process = MODEL.createProcess();
        process.setName("notes-api");
        process.setLifecycle(Lifecycle.APPLICATION);
        process.setImage("notes-api");
        Placement placement = MODEL.createPlacement();
        placement.setMemory("256Mi");
        placement.setCpu("50m");
        process.setPlacement(placement);
        return process;
    }

    @Test
    void aRequiredFeatureIsWrittenEvenWhenItHoldsItsDefault() {
        Map<String, Object> intent = IntentJson.of(process());

        assertThat(intent).contains(entry("name", "notes-api"), entry("image", "notes-api"));
        // `runtime` is required and holds `jvm`, its first literal, which nothing set.
        assertThat(intent).containsKey("runtime");
    }

    @Test
    void anEnumerationIsWrittenAsItsLiteral() {
        assertThat(IntentJson.of(process())).contains(entry("lifecycle", "application"));
    }

    @Test
    void anOptionalFeatureTheDocumentLeftOutIsAbsent() {
        // `cutover` is among them since it became Shared Intent (docs/adr/model/0124).
        assertThat(IntentJson.of(process())).doesNotContainKeys("startupBudget", "probes", "provides", "cutover");
    }

    @Test
    void aListOfLinkedNamesIsWrittenAsTheIdentifiersTheyLinkTo() {
        // The delivery machinery, linked across the documents read together.
        DeliveryPolicy delivery = MODEL.createDeliveryPolicy();
        AnalysisPolicy analysis = MODEL.createAnalysisPolicy();
        analysis.setInterval("30s");
        analysis.setIterations(4);
        analysis.setThreshold(3);
        delivery.setAnalysis(analysis);
        for (String id : new String[] {"flagger", "release-gate"}) {
            Application application = MODEL.createApplication();
            application.setId(id);
            delivery.getMachinery().add(application);
        }

        assertThat(IntentJson.of(delivery)).contains(entry("machinery", List.of("flagger", "release-gate")));
    }

    @Test
    void anOptionalFeatureTheDocumentSetIsWritten() {
        Process process = process();
        process.setStartupBudget("20s");
        Probes probes = MODEL.createProbes();
        HttpProbe readiness = MODEL.createHttpProbe();
        readiness.setPath("/healthz/ready");
        readiness.setPort(8080);
        probes.setReadiness(readiness);
        process.setProbes(probes);

        assertThat(IntentJson.of(process()))
                .doesNotContainKey("startupBudget"); // the sample above is a different object
        assertThat(IntentJson.of(process))
                .contains(
                        entry("startupBudget", "20s"),
                        entry("probes", Map.of("readiness", Map.of("path", "/healthz/ready", "port", 8080))));
    }

    @Test
    void aReferenceIsWrittenAsTheNameItLinked() {
        Process process = process();
        process.getProvides().put("http", 8080);
        Route route = MODEL.createRoute();
        route.setPath("/");
        route.setMatch(Match.PREFIX);
        route.setProcess(process);
        route.setSurface(process.getProvides().get(0));

        assertThat(IntentJson.of(route))
                .contains(entry("process", "notes-api"), entry("surface", "http"), entry("match", "prefix"));
    }

    @Test
    void aMapEntryIsWrittenAsAnObjectAndAListAsAList() {
        Process process = process();
        process.getProvides().put("http", 8080);

        assertThat(IntentJson.of(process())).doesNotContainKey("provides");
        assertThat(IntentJson.of(process())).doesNotContainKey("applications");
        assertThat(IntentJson.of(process)).contains(entry("provides", Map.of("http", 8080)));
    }
}
