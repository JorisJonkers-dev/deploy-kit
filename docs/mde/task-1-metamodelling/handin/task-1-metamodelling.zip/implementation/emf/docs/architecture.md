# The model-driven implementation's structure

Normative for the code under `emf/`, the way
[`docs/architecture.md`](../../docs/architecture.md) is normative for `src/`.
Decisions in [`docs/adr/emf/`](adr/README.md) point their `normative:` field at
sections of this document, and the ADR lint checks that the anchor exists.

This implementation answers to the model in [`spec/v1`](../../spec/v1/00-overview.md)
and to the [parity contract](../../docs/architecture.md#the-parity-contract),
and to nothing in `src/`. Where this document and either of those disagree,
they win and this document is what gets fixed.

## Scope and sunset

This tree implements the whole compiler: parse, validate, resolve and render,
for every case under `spec/v1/examples/`. It is built in the order the course
grades it.

| course task | due | lands here |
|---|---|---|
| Task 1: metamodelling | 2026-09-25 | the two Ecore metamodels, the Xtext grammar and its editor, the OCL constraints; parity on the parsed intent, the descriptor and refused cases |
| Task 2: transformations | 2026-10-16 | the QVT-Operational transformation into the Resolved Deployment; parity on the resolved dependency edges |
| Task 3: code generation | 2026-10-30 | the Acceleo templates rendering the Deliverable Set; parity on `rendered/` |

The tree is deleted in one pull request when both of these hold:

1. the final grade for the course project is recorded;
2. the TypeScript suite is green on every parity case with the `emf` CI job
   removed from `Pipeline Complete`.

What that pull request keeps: every oracle file under `spec/v1/examples/`, the
constraint ledger without its OCL column, and the descriptor check. What it
deletes: this directory; the `emf` CI job and the `ADR contract (emf)` step in
`.github/workflows/ci.yml`; the `java-kotlin` entry in
`.github/workflows/codeql.yml`; `test/emf-wiring.test.ts`, with `RULE-061`,
`RULE-062` and `REQ-015`; the `emf` domain entry in `scripts/lint-adrs.ts` and
the two `emf/` cases in `test/adr-contract.test.ts`; the `emf` exclusion in
`release-please-config.json`, the `emf maven` rule in `renovate.json`, the
`/emf/` line in `.github/CODEOWNERS` and the `mvnw` line in `.gitattributes`;
and the `emf/` mentions in `docs/architecture.md`, `docs/requirements.md`,
`docs/adr/README.md`, `README.md`, `CONTEXT.md` and `CLAUDE.md`.

## Toolchain

Maven, with Eclipse Tycho resolving every EMF-family bundle from one p2
repository: the Eclipse simultaneous release at a dated build, named in
`emf.target` with each unit at an exact version, so EMF, Xtext, OCL,
QVT-Operational and Acceleo arrive at versions released together. The one
Maven Central artifact outside the test libraries is the ANTLR 3 generator the
Xtext generator calls. JDK 21.
No Eclipse IDE, workspace or launch configuration is part of the build: every
step CI runs is `mvn verify` from `emf/`. The projects are nonetheless kept
loadable in Eclipse Modeling Tools for the course's examiners: they import as
existing Maven projects, the metamodels open, the Xtext-generated editor reports
OCL constraint violations while a source file is edited, and committed launch
configurations run the transformation and the generator.

A module that needs a p2 bundle is an Eclipse bundle: a `META-INF/MANIFEST.MF`
naming the bundles it requires, and `eclipse-plugin` packaging. A manifest
switches on the parent's `bundle` profile, which runs the module's tests
through Maven Surefire on a plain classpath, outside OSGi, so every tool is
exercised through the standalone API a command-line run uses. A module that
needs no p2 bundle stays a plain jar, declaring its own test libraries because
the `bundle` profile does not activate for it. `tests/parity` is the one such
module, for the reason [Parity](#parity) records. The profile activates on a
module's `META-INF/MANIFEST.MF` rather than on the tier it sits in, and stays
that way: the directory is documentation, the manifest is the fact.

The first change to this tree is the **EMF scaffold**: the Maven reactor, the
wrapper, the gates and the `emf` CI job, with no EMF dependency and one module,
`parity`, holding the canonical JSON writer and the ledger checks. The second is
the **walking skeleton**, which proves each tool runs headless in CI before any
model work depends on it: an `.ecore` loads, an OCL
invariant fires, the Xtext parser reads a three-line document, a QVTo identity
transformation runs, and an Acceleo template writes one file. Its smoke tests
sit in the module each tool belongs to, and each is deleted by the stage ticket
whose suite covers that tool.

## Modules

Two tiers, under one parent `pom.xml` that owns the Tycho configuration and the
target platform. `bundles/` holds one Maven module per pipeline stage: what
Tycho builds against `emf.target`, and what an examiner imports into Eclipse.
`tests/` holds what Maven alone builds and runs, and what no examiner opens
([0122](adr/emf/0122-bundles-and-tests-are-separate-tiers.md)). The boundary
answers the question a flat list left every reader to work out from a
`pom.xml`: is this file graded, and will a teacher open it.

The directories keep their short names. Tycho's convention is a directory named
for the bundle's symbolic name, but Eclipse names an imported Maven project from
its `artifactId` regardless, so the long names would buy a match nobody reads
and cost every path in the tree.

| module | holds | graded in |
|---|---|---|
| `bundles/metamodel` | the source and target `.ecore` and `.genmodel`, Complete OCL `.ocl` for the source metamodel, the descriptor exporter, and the canonical JSON writer both it and `cli` write through | Task 1 |
| `bundles/syntax` | the Xtext grammar for the authored YAML subset, and the generated editor bundles that run the OCL validators | Task 1 |
| `bundles/resolve` | the QVTo transformations: the lowering onto the Process, and Project Intent with Platform Intent to the Resolved Deployment | Task 2 |
| `bundles/render` | the Acceleo 4 templates from a Resolved Deployment model to the Deliverable Set's files | Task 3 |
| `bundles/cli` | the pipeline entry point: files in, the parsed intent, diagnostics and rendered files out | Task 1 onward |
| `tests/parity` | JUnit suites asserting each stage against the committed oracles, and the witness ledger check | no task grades it |

Beside the two tiers sits `models/`, which is neither: hand-written example
models, in the target metamodel's own XMI. They belong to no module because
two use them from opposite ends. `minimal.resolveddeployment` is what the
Acceleo templates are first run against and what the QVT-Operational
transformation must produce, so it is the target half of both tracers before
either exists. It is **not an oracle**: `resolved.json` binds the production
implementation only, for the reason [Metamodels](#metamodels) gives.

A module may depend on the modules above it in this table and on nothing
below. `tests/parity` depends on no module at all: it reads the files a run
leaves behind, which is what [Parity](#parity) records.

Every module of `bundles/` is Java, without exception. Ecore generates Java,
Xtext's runtime hooks are Java, and a bundle compiles through Tycho's JDT
compiler against a target platform holding no Kotlin unit, so a language other
than Java is a bundle's problem before it is anything else. `tests/` carries
none of those constraints and is Kotlin, the estate's JVM language, with the
test idiom its other repositories run: JUnit 5, AssertJ, ArchUnit, and a test
function named as a sentence in backticks.

## Metamodels

Two hand-written Ecore metamodels, as the project proposal defines them. Both
are committed `.ecore` XMI, with names taken unchanged from
[`CONTEXT.md`](../../CONTEXT.md).

| metamodel | role | holds |
|---|---|---|
| Project Intent | source | the authored Project, Application and Process with everything layer 1 declares, the lowered pair the Effective Intent is written in, and the Platform document the source is resolved against |
| Resolved Deployment | target | every derived value of layer 2 together with the typed Kubernetes and extension resources, identities and output paths the templates write |

The Deliverable Set is not a metamodel: it is the files Acceleo generates from
a Resolved Deployment model. The target metamodel is deliberately not the shape
of the production implementation's Resolved Deployment, which keeps layer 2 in
model words and builds typed objects separately; a model-to-text template reads
one model, so here the two are one package. This is why the parity contract
compares the two implementations through dependency edges and generated files
rather than through `resolved.json`.

Cross-document references, including those from a Project into the Platform
document, are Ecore references, not strings.

Typed Java for each metamodel is generated from its `.genmodel` during the
Maven build into `target/`, and never committed: an MWE2 workflow runs EMF's
`EcoreGenerator` in `generate-sources`, and the generated packages are left out
of formatting, coverage and mutation.

The target metamodel holds the two halves in one package: every decision
layer 2 takes, and one class per resource family of the project proposal's
generated-resources table, each carrying the path it is written to. A template
walks the second half and decides nothing, so no name in it appears in the
first: a `WorkloadFile` carries the controller kind and the strategy that spell
a Process's `cutover`, a `SwitchoverFile` is the Canary that switches a
`blue-green` one, and the `cutover` itself stays on the Process.

The descriptor exporter walks the source `EPackage` reflectively and writes the
descriptor the parity contract fixes. It is the only place the Ecore structure
is compared with anything. Three shapes it normalises: an abstract class is a
union, so it is not listed and a feature that points at one names its concrete
classes; a map entry is not a class, so the feature that holds the entries
is a map; and a class annotated `authored=no` is no part of the authored shape,
so it is not listed either. The last is what keeps `EffectiveProject` and
`EffectiveApplication` out of the descriptor: they are what the lowering writes,
and no document holds one.

## Constraints

Every constraint lives in a Complete OCL file beside the source metamodel,
evaluated by Eclipse OCL standalone in the build and by the Xtext-generated
editor while a file is edited. An
invariant's name is the diagnostic code it emits, so a failed invariant maps to
a diagnostic without a lookup table.

An invariant failure becomes a diagnostic whose path is the JSON Pointer of the
offending object, computed from its containment chain: each containing feature's
name, and the index for a many-valued feature. Validation reports every failed
invariant, never only the first.

The constraints a Platform document and the project files beside it answer
together are invariants in the same file. Eclipse OCL binds one Complete OCL
document to a package for the thread that first loads it, so a second file for
the same package is never evaluated. Such an invariant reads the other
documents through `allInstances()`, whose extent is the resource set a document
was read into, and holds trivially over a document read alone. The pipeline
reads each file of a set alone first, and reads the set together only once
every file holds, so the second reading refuses exactly what the documents
break together. A diagnostic names the file its path points into.

Three consequences of evaluating OCL over Ecore, all recorded here because they
shaped the metamodel. The constraints import the metamodel by its `nsURI`, not
by file, so they bind to the classes the parser instantiates rather than to a
second copy. And EMF reads an unset enumeration as its first literal, so a
vocabulary an invariant tests for absence carries a literal with no spelling:
`Engine::absent` is what an unset `engine` reads as, and `Audience::absent`
what a route's unset `audience` does; a document cannot write either, and the
descriptor leaves them out because a literal the language cannot write is not
part of the vocabulary. And the Platform classes live in the Project Intent
package, because a tier's proxy is an Application a project file declares, and
one package is what lets that be an Ecore reference.

The constraint ledger's OCL column lives in `emf/`: a table mapping each
`CONS-NNN` id to the OCL invariant that enforces it. `tests/parity` fails when a
ledger constraint has no invariant, or an invariant names a code no ledger row
carries.

## Concrete syntax

The Xtext grammar parses the same authored `.project.yml` and
`platform.intent.yml` files the TypeScript compiler reads. It covers the YAML
subset those files use, with indentation handled by synthetic block tokens, and
refuses anything outside the subset with a diagnostic rather than a guess.

The grammar imports the hand-written source metamodel, so the parser produces
instances of the graded metamodel directly. A union in the model is a union in
the grammar: a probe is HTTP or TCP, a probe policy is a block or the word
`none`, and a grant is keyed by its engine, which a grant that has one writes
first. Both languages bind the `.yml` extension, because EMF resolves a resource
factory by the last extension alone, so which document a file holds is the
file name's to say: the pipeline creates a `platform.intent.yml` through the
Platform language's resource factory and a `*.project.yml` through the project
language's, into one resource set. The Platform grammar inherits the project
grammar, its terminals, block tokens and scalars included, and adds only its
own rules. There is no inferred syntax metamodel and no mapping step between
parsing and validation.

A plain scalar holds no colon: the lexer cannot tell `sha256:6f1c` from a key
without looking past the colon, so a value that carries one, a digest or a URL,
is quoted in the authored files.

A route's and a scrape's `process` and `surface` are cross-references, linked by
a scope provider that offers the Processes of the Application holding them and the
surfaces the linked Process provides. A name that links to nothing becomes the
specification's code, `E_UNKNOWN_PROCESS` or `E_UNKNOWN_SURFACE`, at the pointer
of the route or scrape; a surface whose Process did not link is not reported as
well. A tier's `traefik` is the one name that reaches another document: it links to
an Application any project file of the set declares, and one that links to
nothing is `E_UNKNOWN_TIER_PROXY` at the tier. A Platform document read alone
leaves it unlinked, and its intent writes the name as authored. A dependency
edge's names reach other documents and stay names until the composed union
links them.

Indentation is not the grammar's concern: a token source turns the block
structure into the synthetic `BEGIN` and `END` tokens the rules read, and folds
a scalar written over several lines into one token. A line
indented further than the one before it opens a block, a dash opens one around
the item that follows it, and a flow collection opens and closes one on a single
line, so `{ path: /, match: prefix }` and the same keys written as an indented
block parse through one rule. The rules themselves are unordered groups, because
the order of keys in a mapping is not meaning.

The generated editor is configured to run the OCL validators and to mark each
constraint violation on the source line it concerns, with the diagnostic code as
its message. It is built by the same Maven and Tycho build as an Eclipse plugin;
CI builds it but never runs it.

## Transformation

Two QVT-Operational transformations, both run through the standalone
transformation executor.

**The lowering** comes first and stays inside layer 1: Shared Intent declared at
the Project or an Application is merged onto the Processes that hold it, and what
comes out is the Effective Intent, in which `EffectiveProject` and
`EffectiveApplication` carry no Shared Intent at all and the Process carries all
of it ([0125](../../docs/adr/model/0125-the-effective-intent-is-a-lowering.md)).
Source and target are the same metamodel, because the shapes differ by two
classes and a Process is a Process in both. It runs after the constraints and
before composition, and it has no error path: a duplicate is refused before it,
so the mapping is total. Lists extend each other keyed by the family's own
identity, the lowest declaration of one thing holds, and a quantity comes from
the Process, which is the whole of what it does.

**The resolution** derives a Resolved Deployment model from the lowered Project
Intent model. It reads the Effective Intent and never the authored shape, which
is what keeps a derivation from having to union three levels for itself. Every derivation `spec/v1/20-resolved-deployment.md` names is a mapping
or a helper in it; a derived value with no mapping is a gap a parity case
exposes, through the dependency edges or the generated files. The resolved
dependency edges are exported from the target model as canonical JSON and
compared with `expected/dependencies.json`.

## Text generation

Acceleo 4 templates generate the Deliverable Set's YAML and JSON files from a
Resolved Deployment model, run through Acceleo's standalone API. Until the
transformation covers a case, a template test reads a hand-written Resolved
Deployment model kept inside `emf/`; it is test input, never an oracle. Output is compared byte for byte with the
committed `rendered/` tree, so whitespace, key order and the `GENERATED` header
are template decisions made to match the oracle, not presentation.

## Parity

`tests/parity` holds this repository's own evidence: the suites that assert each stage
against the committed oracles, the ledger checks, and the module rules. It is
built and run by Maven only, and no examiner opens it.

It reaches the pipeline through the pipeline's own interface, and through nothing
else ([0121](adr/emf/0121-parity-crosses-the-cli-file-interface.md)): arguments
and input files in; an exit code, diagnostics, the parsed intent, the descriptor
and the rendered tree out. A run of the build leaves those files under the build
output of the module that wrote them, one directory per case, mirroring
`spec/v1/examples/` so a written file and its oracle are obviously a pair:
`bundles/cli/target/parity/<case>/` holds `intent.json` or `diagnostics.json` beside the
`exit` the run ended on, and `bundles/metamodel/target/parity/` holds `descriptor.json`.
Every case also leaves each document it reads as an XMI instance of the source
metamodel, named after its authored file (`notes.project.yml` leaves
`notes.project.xmi`), for a reader who opens it in Eclipse without the grammar. A
refused case leaves its model too, and a set's models link to each other, so the
refusal reproduces there by validating it. No oracle compares them, because the
parity contract is JSON. None of them is committed.

So the module holds no EMF type, needs no p2 bundle, and builds as a plain jar
with no `META-INF/MANIFEST.MF` and no `build.properties`. Its `src/main` holds
`Ledgers`; the canonical JSON writer sits in `bundles/metamodel`, the lowest module that
writes a canonical file, because the pipeline writes what the suite used to
serialise. A value a parity case asserts on is a value the pipeline writes, and a
derivation with no output file is not evidence.

Two things follow from depending on no module, and both are enforced rather than
remembered. A case asserts its file exists before comparing it, so a file the run
owes and did not write fails as a missing file rather than as a skipped case,
which is a different absence from a case with no committed oracle, and that one
is listed as not yet a parity case. And nothing puts the other modules' classes on this module's
classpath, so `ArchitectureTest` reads their class directories by path and
`EMF-017` fails an import that holds no module: `withOptionalLayers` would
otherwise excuse every empty layer and let `EMF-010` and `EMF-011` pass while
proving nothing.

## Witnesses

A behaviour ledger row whose behaviour is the model's own is proved in both
implementations. `emf/docs/witnesses.md` lists, for each such `REQ-NNN` id, the
JUnit test that proves it here, in whichever language its module is written.
`tests/parity` fails when a model row in
`docs/requirements.md` has no witness in that file, or a witness names a test
that does not exist or an id that no row carries.

## Gates

One CI job, `emf`, runs `./mvnw -B -ntp verify` in `emf/` on the JDK named by
`emf/.java-version` and is required by `Pipeline Complete`. The wrapper
downloads the Maven distribution pinned by checksum; no wrapper jar is
committed. The job writes one line to its summary: tests, line coverage and
mutation score, from `scripts/summary.sh`. The ADR lint for `emf/docs/adr/` runs
in the existing `contracts` job, as `node scripts/lint-adrs.ts emf`.

`verify` runs these gates, in this order, and fails on the first that does not
hold ([0115](adr/emf/0115-the-emf-gates-are-estate-shaped.md)):

| gate | plugin | fails when |
|---|---|---|
| toolchain | `maven-enforcer-plugin` | the JDK is not 21, Maven is not 3.9, a plugin version is unpinned, dependency versions do not converge outside a bundle, or anything declares a distribution target |
| compile | `maven-compiler-plugin`, `tycho-compiler-plugin` in a bundle, or `kotlin-maven-plugin` in the test tier | any `-Xlint:all` warning, in a bundle any warning the JDT compiler reports, and in the test tier any warning `kotlinc` reports |
| tests | `maven-surefire-plugin` | a JUnit test fails, including the ArchUnit module rules and the ledger checks |
| format | `spotless-maven-plugin` | Java source differs from palantir-java-format, or Kotlin source from ktlint; `./mvnw spotless:apply` fixes either |
| coverage | `jacoco-maven-plugin` | line or branch coverage of a module's hand-written classes falls below the floor in `emf/pom.xml` |
| mutation | `pitest-maven` | the mutation score of a module's hand-written classes falls below the threshold in `emf/pom.xml` |

Every rule these gates enforce is listed in [the rule ledger](rules.md), and
every model behaviour's JUnit proof in [the witness list](witnesses.md), in
whichever language its module is written.

CodeQL analyses the Java under `emf/` as `java-kotlin` with no build, ignoring
build output and generated sources; `test/emf-wiring.test.ts` at the root holds
that configuration and the `emf` job to the tree they describe.
